# smart.who.int.ccc#0.1.0: WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies

## Pages

* [Home](index.md)
* [Changes](changes.md)
* [Artifacts Summary](artifacts.md)
* [DAK API Documentation Hub](dak-api.md)
* [Downloads](downloads.md)
* [Guidance](guidance.md)
* [Quick Start](quick-start.md)
* [Documentation](documentation.md)
* [License](license.md)

## Resources

### ActivityDefinitions

* [Ccc.b10-14.symptoms.2m.p](ActivityDefinition-Ccc.b10-14.symptoms.2m.p.md)
* [Ccc.b10-16.signs.2m.p](ActivityDefinition-Ccc.b10-16.signs.2m.p.md)
* [Ccc.b18-21.signs.2m.m](ActivityDefinition-Ccc.b18-21.signs.2m.m.md)
* [Ccc.b18-21.symptoms.2m.m](ActivityDefinition-Ccc.b18-21.symptoms.2m.m.md)
* [Ccc.b22.assessmentstests](ActivityDefinition-Ccc.b22.assessmentstests.md)
* [Ccc.b22.breastfeeding](ActivityDefinition-Ccc.b22.breastfeeding.md)
* [Ccc.b22.bronchodilatortest](ActivityDefinition-Ccc.b22.bronchodilatortest.md)
* [Ccc.b22.fluidtest](ActivityDefinition-Ccc.b22.fluidtest.md)
* [Ccc.b22.hemoglobin](ActivityDefinition-Ccc.b22.hemoglobin.md)
* [Ccc.b22.respiratoryrate](ActivityDefinition-Ccc.b22.respiratoryrate.md)
* [Ccc.b22.secondtemperature](ActivityDefinition-Ccc.b22.secondtemperature.md)
* [Ccc.b23.classification](ActivityDefinition-Ccc.b23.classification.md)
* [Ccc.b23.classification.m](ActivityDefinition-Ccc.b23.classification.m.md)
* [Ccc.b6.measurements](ActivityDefinition-Ccc.b6.measurements.md)
* [Ccc.b7.lti-dangersigns](ActivityDefinition-Ccc.b7.lti-dangersigns.md)
* [Ccc.treatment](ActivityDefinition-Ccc.treatment.md)
* [Ccca.registration.p](ActivityDefinition-Ccca.registration.p.md)
* [Cccb.registration.e](ActivityDefinition-Cccb.registration.e.md)

### ImplementationGuides

* [WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies](index.md)

### Libraries

* [Ccc.B10-14.Symptoms.2m.p](Library-Cccb1014symptoms2mp.md)
* [Ccc.B10-16.Signs.2m.p](Library-Cccb1016signs2mp.md)
* [Ccc.B18-21.Signs.2m.m](Library-Cccb1821signs2mm.md)
* [Ccc.B18-21.Symptoms.2m.m](Library-Cccb1821symptoms2mm.md)
* [Ccc.B22.AssessmentsTests](Library-Cccb22assessmentstests.md)
* [Ccc.B22.BreastFeeding](Library-Cccb22breastfeeding.md)
* [Ccc.B22.FluidTest](Library-Cccb22fluidtest.md)
* [Ccc.B22.RespiratoryRate](Library-Cccb22respiratoryrate.md)
* [Ccc.B22.SecondTemperature](Library-Cccb22secondtemperature.md)
* [Ccc.B23.Classification](Library-Cccb23classification.md)
* [Ccc.B23.Classification.m](Library-Cccb23classificationm.md)
* [Ccc.B6.Measurements](Library-Cccb6measurements.md)
* [Ccc.B7.LTI-DangerSigns](Library-Cccb7ltidangersigns.md)
* [CccBase](Library-Cccbase.md)
* [Ccc.CombinedDataElements](Library-Ccccombineddataelements.md)
* [Ccccondition](Library-Ccccondition.md)
* [Cccdt01](Library-Cccdt01.md)
* [Cccobservation](Library-Cccobservation.md)
* [Cccobservation-valueset](Library-Cccobservationvalueset.md)
* [Ccc.Treatment](Library-Ccctreatment.md)
* [Cccvalueset](Library-Cccvalueset.md)
* [Ccc.Z.Score](Library-Ccczscore.md)

### PlanDefinitions

* [Cccdt01](PlanDefinition-Cccdt01.md)

### Questionnaires

* [Ccc.B10-14.Symptoms.2m.p](Questionnaire-Ccc.b10-14.symptoms.2m.p.md)
* [Ccc.B10-16.Signs.2m.p](Questionnaire-Ccc.b10-16.signs.2m.p.md)
* [Ccc.B18-21.Signs.2m.m](Questionnaire-Ccc.b18-21.signs.2m.m.md)
* [Ccc.B18-21.Symptoms.2m.m](Questionnaire-Ccc.b18-21.symptoms.2m.m.md)
* [Ccc.B22.AssessmentsTests](Questionnaire-Ccc.b22.assessmentstests.md)
* [Ccc.B22.BreastFeeding](Questionnaire-Ccc.b22.breastfeeding.md)
* [Ccc.B22.BronchodilatorTest](Questionnaire-Ccc.b22.bronchodilatortest.md)
* [Ccc.B22.FluidTest](Questionnaire-Ccc.b22.fluidtest.md)
* [Ccc.B22.Hemoglobin](Questionnaire-Ccc.b22.hemoglobin.md)
* [Ccc.B22.RespiratoryRate](Questionnaire-Ccc.b22.respiratoryrate.md)
* [Ccc.B22.SecondTemperature](Questionnaire-Ccc.b22.secondtemperature.md)
* [Ccc.B23.Classification](Questionnaire-Ccc.b23.classification.md)
* [Ccc.B23.Classification.m](Questionnaire-Ccc.b23.classification.m.md)
* [Ccc.B6.Measurements](Questionnaire-Ccc.b6.measurements.md)
* [Ccc.B7.LTI-DangerSigns](Questionnaire-Ccc.b7.lti-dangersigns.md)
* [Ccc.Treatment](Questionnaire-Ccc.treatment.md)
* [CccA.Registration.P](Questionnaire-Ccca.registration.p.md)
* [CccB.Registration.E](Questionnaire-Cccb.registration.e.md)

### StructureMaps

* [Ccc.b10-14.symptoms.2m.p](StructureMap-Ccc.b10-14.symptoms.2m.p.md)
* [Ccc.b10-16.signs.2m.p](StructureMap-Ccc.b10-16.signs.2m.p.md)
* [Ccc.b18-21.signs.2m.m](StructureMap-Ccc.b18-21.signs.2m.m.md)
* [Ccc.b18-21.symptoms.2m.m](StructureMap-Ccc.b18-21.symptoms.2m.m.md)
* [Ccc.b22.assessmentstests](StructureMap-Ccc.b22.assessmentstests.md)
* [Ccc.b22.breastfeeding](StructureMap-Ccc.b22.breastfeeding.md)
* [Ccc.b22.bronchodilatortest](StructureMap-Ccc.b22.bronchodilatortest.md)
* [Ccc.b22.fluidtest](StructureMap-Ccc.b22.fluidtest.md)
* [Ccc.b22.hemoglobin](StructureMap-Ccc.b22.hemoglobin.md)
* [Ccc.b22.respiratoryrate](StructureMap-Ccc.b22.respiratoryrate.md)
* [Ccc.b22.secondtemperature](StructureMap-Ccc.b22.secondtemperature.md)
* [Ccc.b23.classification](StructureMap-Ccc.b23.classification.md)
* [Ccc.b23.classification.m](StructureMap-Ccc.b23.classification.m.md)
* [Ccc.b6.measurements](StructureMap-Ccc.b6.measurements.md)
* [Ccc.b7.lti-dangersigns](StructureMap-Ccc.b7.lti-dangersigns.md)
* [Ccc.treatment](StructureMap-Ccc.treatment.md)
* [Ccca.registration.p](StructureMap-Ccca.registration.p.md)
* [Cccb.registration.e](StructureMap-Cccb.registration.e.md)
