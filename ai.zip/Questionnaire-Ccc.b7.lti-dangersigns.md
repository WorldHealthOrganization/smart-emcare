# Ccc.B7.LTI-DangerSigns - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ccc.B7.LTI-DangerSigns**

## Questionnaire: Ccc.B7.LTI-DangerSigns
Branch:



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "Ccc.b7.lti-dangersigns",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-targetStructureMap",
    "valueCanonical" : "https://smart.who.int/ccc/StructureMap/Ccc.b7.lti-dangersigns"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://smart.who.int/ccc/Library/Cccb7ltidangersigns"
  }],
  "url" : "https://smart.who.int/ccc/Questionnaire/Ccc.b7.lti-dangersigns",
  "version" : "0.1.0",
  "name" : "Ccc.B7.LTI-DangerSigns",
  "title" : "Ccc.B7.LTI-DangerSigns",
  "status" : "active",
  "experimental" : false,
  "subjectType" : ["Patient"],
  "date" : "2026-04-07T13:45:53+00:00",
  "publisher" : "World Health Organization (WHO)",
  "contact" : [{
    "name" : "World Health Organization (WHO)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  },
  {
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageinmonth.cql"
      }
    }],
    "linkId" : "AgeInMonth.cql",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B7.DE02",
    "text" : "Convulsing Now",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "popup",
            "display" : "Popup"
          }],
          "text" : "Popup"
        }
      }],
      "linkId" : "Ccc.B7.DE02-help",
      "text" : "During a convulsion, the child’s arms and legs stiffen because the muscles are contracting. The child may lose consciousness or not be able to respond to spoken directions.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B7.DE02').answer.first().value =  true"
      }
    }],
    "linkId" : "Ccc.B7-B8-B9.DE01",
    "text" : "Continue to Assess Sick Child",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B7-B8-B9.DE03",
        "display" : "End consultation"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B7-B8-B9.DE02",
        "display" : "Stabilised, continue consultation"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B7.DE02').answer.first().value =  false or %resource.repeat(item).where(linkId='Ccc.B7-B8-B9.DE01').answer.first().value.code =  'Ccc.B7-B8-B9.DE02'"
      }
    }],
    "linkId" : "stable-child",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B7.DE02').answer.first().value = false and AgeInMonth.cql >=2"
        }
      }],
      "linkId" : "Ccc.B7.DE03",
      "text" : "Convulsion(s) in this Illness",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE03-help",
        "text" : "During a convulsion, the child’s arms and legs stiffen because the muscles are contracting. The child may lose consciousness or not be able to respond to spoken directions. Use words the caregiver understands. For example, the caregiver may call convulsions “fits” or “spasms.”",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      }],
      "linkId" : "Ccc.B7.DE08b",
      "text" : "Unconscious or Lethargic",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE08b-help",
        "text" : "A <b>lethargic child is not awake and alert when she should be.</b> The child is drowsy and does not show interest in what is happening around her.</p>\n\n\t<p>Often the lethargic child does not look at his caregiver or watch your face when you talk, or will not respond if you clap or snap your fingers. The child may stare blankly and appear not to notice what is going on around him.</p>\n\n\t<p>An <b>unconscious child cannot be wakened.</b> He does not respond when he is touched, shaken, or spoken to. Ask the caregiver if the child seems unusually sleepy or if she cannot wake the child. Look to see if the child wakens when the caregiver talks or shakes the child or when you clap your hands.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE08b').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B7.DE08",
      "text" : "Unconscious",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE08-help",
        "text" : "An <b>unconscious child cannot be wakened</b>. He does not respond when he is touched, shaken, or spoken to. Ask the caregiver if the child seems unusually sleepy or if she cannot wake the child. Look to see if the child wakens when the caregiver talks or shakes the child or when you clap your hands.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE08b').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B7.DE08a",
      "text" : "Lethargic",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE08a-help",
        "text" : "A <b>lethargic child is not awake and alert when she should be.</b> The child is drowsy and does not show interest in what is happening around her.</p>\n\n\t<p>Often the lethargic child does not look at his caregiver or watch your face when you talk, or will not respond if you clap or snap your fingers. The child may stare blankly and appear not to notice what is going on around him.  An unconscious child cannot be wakened. He does not respond when he is touched, shaken, or spoken to. Ask the caregiver if the child seems unusually sleepy or if she cannot wake the child. Look to see if the child wakens when the caregiver talks or shakes the child or when you clap your hands.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      }],
      "linkId" : "Ccc.B7.DE09",
      "text" : "Not able to drink or breastfeed",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE09-help",
        "text" : "A child has the sign not able to drink or breastfeed <b>if the child is not able to suck or swallow when offered a drink or breast milk.</b></p>\n\n\t<p><b>When you ask the caregiver if the child is able to drink, make sure that she understands the question.</b> If she says that her child is not able to drink or breastfeed, ask her to describe what happens when she offers the child something to drink. For example, is the child able to take fluid into his mouth and swallow it?<br />\nIf you are not sure about the caregiver’s answer, <b>ask her to offer the child a drink of clean water or breast milk. Look to see if the child is swallowing the water or breast milk.</b></p>\n\n\t<p>A child who is breastfed may have difficulty sucking when his nose is blocked. <b>If the child’s nose is blocked, clear it.</b> If the child can breastfeed after the nose is cleared, the child does not have the danger sign, “not able to drink or breastfeed.”",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      }],
      "linkId" : "Ccc.B7.DE10",
      "text" : "Vomiting Everything",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B7.DE10-help",
        "text" : "A child who is <b>not able to hold anything down at all</b> has the sign “vomits everything” – everything that goes down comes back up. <b>A child who vomits everything will not be able to hold down food, fluids, or oral drugs. A child who vomits several times but can hold down some fluids does not have this general danger sign.</b>  When you ask the question, use words that the caregiver understands. Give her time to answer. If the caregiver is not sure if the child is vomiting everything, help her to make her answer clear. For example, ask the caregiver how often the child vomits. Also ask if each time the child swallows food or fluids, does the child vomit? If you are not sure of the caregiver’s answers, <b>ask her to offer the child a drink. See if the child vomits.</b>",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
        "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.fluidtest"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE09').answer.first().value = true or %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE10').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.B22.FluidTest",
      "type" : "group",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().empty() and ( %resource.repeat(item).where(linkId='oftrp').answer.empty()  or %resource.repeat(item).where(linkId='oftrp').answer.first().value=true )"
          }
        }],
        "linkId" : "Ccc.B22.DE08",
        "text" : "Oral Fluid Test Results",
        "type" : "choice",
        "required" : true,
        "repeats" : false,
        "answerOption" : [{
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE09",
            "display" : "Completely Unable to Drink"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE10",
            "display" : "Vomits Immediately / Everything"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE11",
            "display" : "Drinks Poorly"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE12",
            "display" : "Drinks Eagerly / Thirstily"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE13",
            "display" : "Drinks Normally"
          }
        }],
        "item" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.org/fhir/questionnaire-item-control",
                "code" : "help"
              }]
            }
          }],
          "linkId" : "Ccc.B22.DE08-help",
          "text" : "If a child is unconscious do not try to carry out an oral fluid test (Exact wording <span class=\"caps\">TBC</span>) &#8211; Pop Up</p>\n\n\t<p>If a breastfeeding assessment and an Oral Fluid test is recommended for a child that is only breastfed then a pop up is required to ensure that the health care worker observes the signs for both and provides results for both tests. </p>\n\n\t<p>Oral Fluid Test<br />\nIf it is not possible to perform an oral fluid test, the health care worker should assume that the child is vomiting everything<br />\nFor a child under 6 months the health care worker can offer for the mother to breastfeed instead of receiving fluids</p>\n\n\t<p>Caution: Do not force fluids into an unconscious child , it can be dangerous. The fluid can cause them to choke or the fluid can go into their lungs. </p>\n\n\t<p>Pop up box to be made available with instructions on how to carry out an oral fluid test.<br />\nAdditional information <span class=\"caps\">TBC</span>",
          "type" : "display"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "check-box",
              "display" : "Check-box"
            }],
            "text" : "Check-box"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE14",
        "type" : "choice",
        "required" : true,
        "repeats" : true,
        "answerOption" : [{
          "valueCoding" : {
            "code" : "Ccc.B22.DE14",
            "display" : "Unable to Perform Oral Fluid Test"
          }
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
          "valueCode" : "horizontal"
        },
        {
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
          "valueBoolean" : true
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE09').answer.first().value = true or %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE10').answer.first().value =  true"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().exists() and (%resource.repeat(item).where(linkId='DS').answer.first().value = true  or %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.where(value.code='Ccc.B22.DE09').exists() or %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.where(value.code='Ccc.B22.DE10').exists() )"
          }
        }],
        "linkId" : "Ccc.B22.DE14a",
        "text" : "Completely Unable to Drink or Vomits Immediately / Everything",
        "type" : "boolean",
        "required" : false,
        "repeats" : false
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
          "valueCode" : "horizontal"
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().value = true and %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE09').answer.first().value= false and %resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B7.DE10').answer.first().value = false"
          }
        }],
        "linkId" : "Ccc.B22.DE15",
        "text" : "Has the Child had anything to drink today?",
        "type" : "boolean",
        "required" : false,
        "repeats" : false
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='stable-child').repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE15').answer.first().value = true"
          }
        }],
        "linkId" : "Ccc.B22.DE16",
        "text" : "How did the child last drink",
        "type" : "choice",
        "required" : false,
        "repeats" : false,
        "answerOption" : [{
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE09",
            "display" : "Completely Unable to Drink"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE10",
            "display" : "Vomits Immediately / Everything"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE11",
            "display" : "Drinks Poorly"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE12",
            "display" : "Drinks Eagerly / Thirstily"
          }
        },
        {
          "valueCoding" : {
            "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
            "code" : "Ccc.B22.DE13",
            "display" : "Drinks Normally"
          }
        }]
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ds"
      }
    }],
    "linkId" : "DS",
    "text" : "Danger Signs",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "now()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    }],
    "linkId" : "timestamp",
    "type" : "dateTime",
    "required" : false
  }]
}

```
