# Home - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://smart.who.int/ccc/ImplementationGuide/smart.who.int.ccc | *Version*:0.1.0 |
| Draft as of 2022-01-06 | *Computable Name*:Ccc |

This WHO Implementation Guide for Immunizations details how to use Health Level 7 (HL7) Fast Healthcare Interoperability Resources (FHIR) for consistent digital representation of Immunization services.

 This implementation guide and set of artifacts are still undergoing development. 

 Content is for demonstration purposes only. 

### Summary

This implementation guide includes a machine-readable representation of WHO guidelines for Immunizations, as documented in the WHO Digital Adaptation Kit for Immunizations (link forthcoming) and explicitly encodes computer-interoperable logic, including data models, terminologies, and logic expressions, in a computable language to support implementation of Immunization use cases by WHO Member States.

The guide is part of the [WHO SMART Guidelines approach](https://www.who.int/teams/digital-health-and-innovation/smart-guidelines) to support countries to integrate WHO global health and data recommendations into digital systems accurately and consistently. It defines a series of FHIR Resources, Profiles, Extensions, and Terminology based on the [WHO Digital Adaptation Kit for Immunizations](https://www.who.int/publications/i/item/9789240099456).

Supporting guidance, recommendations, resources, and standards are included in the [References](references.md) and [Dependencies](dependencies.md).

### About this implementation guide

This implementation guide is broken into the following levels of [knowledge representation](https://hl7.org/fhir/uv/cpg/documentation-approach-06-01-levels-of-knowledge-representation.html):

* [Home](index.md) - contains references to the guidance, guidelines, policies and recommendations underpinning this implementation guide.
* [Business Requirements](business-requirements.md) - contains the requirements for this implementation guide including the definition of key concepts, use cases, and a data dictionary.
* [Data Models and Exchange](data-models-and-exchange.md) - contains the data models and data exchange protocols with actors and transactions defined.
* [Deployment Guidance ](deployment.md) - contains relevant technical specifications and guidance, testing resources, reference implementation materials, and supporting guidance for adaptation to local contexts.

This guide is prepared to facilitate digital implementation of WHO Immunization guidelines by providing FHIR-based computable representations of and implementation guidance for using the key components of the WHO Digital adaptation kit (DAK) for immunizations:

* Health Interventions & Recommendations
* Generic Personas
* User Scenarios
* Business Processes & Workflows
* Core Data Elements
* Decision Support Logic
* Indicators & Monitoring
* Functional & Non-functional Requirements

This guide is a companion to the Digital Adaptation Kit (DAK) and should be used side-by-side with it. Implementers are strongly encouraged to make use of the Digital Adaptation Kit. The focus of this guide is on the explanation and use of the computable artifacts.

This guide assumes use of the following resources:

* [IPS Patient](http://hl7.org/fhir/uv/ips/StructureDefinition/Patient-uv-ips)
* [CPG ActivityDefinitions](https://hl7.org/fhir/uv/cpg/artifacts.html#activitydefinition-index)
* For a complete listing of the artifacts defined in this implementation guide, refer to the [Artifact Index](artifacts.md).
* A complete offline copy of this implementation guide can be found on the [Downloads](downloads.md) page.
* This Implementation Guide makes use of [Clinical Quality Language](https://cql.hl7.org/) for the decision support artifacts including the PlanDefinitions and Measures. They are used to express how a calculation should occur and can be used with a CQL engine in order to process the decision or indicator directly from the applicable FHIR resources. Links to this specification, the FHIR Clinical Practice Guidelines Speciciation, and other helpful resources can be found in the Support dropdown.

### Disclaimer

The specification herewith documented is a demo working specification and may not be used for any implementation purposes. This draft is provided without warranty of completeness or consistency and the official publication supersedes this draft. No liability can be inferred from the use or misuse of this specification or its consequences.

This publication includes IP covered under the following statements.

* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://terminology.hl7.org/6.1.0/CodeSystem-v3-ucum.html): [Ccc.B10-16.Signs.2m.p](Questionnaire-Ccc.b10-16.signs.2m.p.md), [Ccc.B18-21.Signs.2m.m](Questionnaire-Ccc.b18-21.signs.2m.m.md)... Show 6 more, [Ccc.B22.AssessmentsTests](Questionnaire-Ccc.b22.assessmentstests.md), [Ccc.B22.RespiratoryRate](Questionnaire-Ccc.b22.respiratoryrate.md), [Ccc.B22.SecondTemperature](Questionnaire-Ccc.b22.secondtemperature.md), [Ccc.B23.Classification](Questionnaire-Ccc.b23.classification.md), [Ccc.B6.Measurements](Questionnaire-Ccc.b6.measurements.md) and [CccA.Registration.P](Questionnaire-Ccca.registration.p.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [PlanDefinitionType](http://terminology.hl7.org/6.1.0/CodeSystem-plan-definition-type.html): [Cccdt01](PlanDefinition-Cccdt01.md)
* [UsageContextType](http://terminology.hl7.org/6.1.0/CodeSystem-usage-context-type.html): [ActivityDefinition/Ccc.b10-14.symptoms.2m.p](ActivityDefinition-Ccc.b10-14.symptoms.2m.p.md), [ActivityDefinition/Ccc.b10-16.signs.2m.p](ActivityDefinition-Ccc.b10-16.signs.2m.p.md)... Show 16 more, [ActivityDefinition/Ccc.b18-21.signs.2m.m](ActivityDefinition-Ccc.b18-21.signs.2m.m.md), [ActivityDefinition/Ccc.b18-21.symptoms.2m.m](ActivityDefinition-Ccc.b18-21.symptoms.2m.m.md), [ActivityDefinition/Ccc.b22.assessmentstests](ActivityDefinition-Ccc.b22.assessmentstests.md), [ActivityDefinition/Ccc.b22.breastfeeding](ActivityDefinition-Ccc.b22.breastfeeding.md), [ActivityDefinition/Ccc.b22.bronchodilatortest](ActivityDefinition-Ccc.b22.bronchodilatortest.md), [ActivityDefinition/Ccc.b22.fluidtest](ActivityDefinition-Ccc.b22.fluidtest.md), [ActivityDefinition/Ccc.b22.hemoglobin](ActivityDefinition-Ccc.b22.hemoglobin.md), [ActivityDefinition/Ccc.b22.respiratoryrate](ActivityDefinition-Ccc.b22.respiratoryrate.md), [ActivityDefinition/Ccc.b22.secondtemperature](ActivityDefinition-Ccc.b22.secondtemperature.md), [ActivityDefinition/Ccc.b23.classification](ActivityDefinition-Ccc.b23.classification.md), [ActivityDefinition/Ccc.b23.classification.m](ActivityDefinition-Ccc.b23.classification.m.md), [ActivityDefinition/Ccc.b6.measurements](ActivityDefinition-Ccc.b6.measurements.md), [ActivityDefinition/Ccc.b7.lti-dangersigns](ActivityDefinition-Ccc.b7.lti-dangersigns.md), [ActivityDefinition/Ccc.treatment](ActivityDefinition-Ccc.treatment.md), [ActivityDefinition/Ccca.registration.p](ActivityDefinition-Ccca.registration.p.md) and [ActivityDefinition/Cccb.registration.e](ActivityDefinition-Cccb.registration.e.md)
* [ActCode](http://terminology.hl7.org/6.1.0/CodeSystem-v3-ActCode.html): [ActivityDefinition/Ccc.b10-14.symptoms.2m.p](ActivityDefinition-Ccc.b10-14.symptoms.2m.p.md), [ActivityDefinition/Ccc.b10-16.signs.2m.p](ActivityDefinition-Ccc.b10-16.signs.2m.p.md)... Show 16 more, [ActivityDefinition/Ccc.b18-21.signs.2m.m](ActivityDefinition-Ccc.b18-21.signs.2m.m.md), [ActivityDefinition/Ccc.b18-21.symptoms.2m.m](ActivityDefinition-Ccc.b18-21.symptoms.2m.m.md), [ActivityDefinition/Ccc.b22.assessmentstests](ActivityDefinition-Ccc.b22.assessmentstests.md), [ActivityDefinition/Ccc.b22.breastfeeding](ActivityDefinition-Ccc.b22.breastfeeding.md), [ActivityDefinition/Ccc.b22.bronchodilatortest](ActivityDefinition-Ccc.b22.bronchodilatortest.md), [ActivityDefinition/Ccc.b22.fluidtest](ActivityDefinition-Ccc.b22.fluidtest.md), [ActivityDefinition/Ccc.b22.hemoglobin](ActivityDefinition-Ccc.b22.hemoglobin.md), [ActivityDefinition/Ccc.b22.respiratoryrate](ActivityDefinition-Ccc.b22.respiratoryrate.md), [ActivityDefinition/Ccc.b22.secondtemperature](ActivityDefinition-Ccc.b22.secondtemperature.md), [ActivityDefinition/Ccc.b23.classification](ActivityDefinition-Ccc.b23.classification.md), [ActivityDefinition/Ccc.b23.classification.m](ActivityDefinition-Ccc.b23.classification.m.md), [ActivityDefinition/Ccc.b6.measurements](ActivityDefinition-Ccc.b6.measurements.md), [ActivityDefinition/Ccc.b7.lti-dangersigns](ActivityDefinition-Ccc.b7.lti-dangersigns.md), [ActivityDefinition/Ccc.treatment](ActivityDefinition-Ccc.treatment.md), [ActivityDefinition/Ccca.registration.p](ActivityDefinition-Ccca.registration.p.md) and [ActivityDefinition/Cccb.registration.e](ActivityDefinition-Cccb.registration.e.md)


