# Ccc.B22.AssessmentsTests - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ccc.B22.AssessmentsTests**

## Questionnaire: Ccc.B22.AssessmentsTests
Branch:



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "Ccc.b22.assessmentstests",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-targetStructureMap",
    "valueCanonical" : "https://smart.who.int/ccc/StructureMap/Ccc.b22.assessmentstests"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://smart.who.int/ccc/Library/Cccb22assessmentstests"
  }],
  "url" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.assessmentstests",
  "version" : "0.1.0",
  "name" : "Ccc.B22.AssessmentsTests",
  "title" : "Ccc.B22.AssessmentsTests",
  "status" : "active",
  "experimental" : false,
  "subjectType" : ["Patient"],
  "date" : "2026-04-07T13:36:32+00:00",
  "publisher" : "World Health Organization (WHO)",
  "contact" : [{
    "name" : "World Health Organization (WHO)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  },
  {
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "force-collection"
      }
    }],
    "linkId" : "force-collection",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageinmonths"
      }
    }],
    "linkId" : "AgeInMonths",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageindays"
      }
    }],
    "linkId" : "AgeInDays",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-breastfeedingtest"
      }
    }],
    "linkId" : "a-BreastFeedingTest",
    "text" : "applicability-BreastFeedingTest",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-respiratoryrate"
      }
    }],
    "linkId" : "a-RespiratoryRate",
    "text" : "applicability-RespiratoryRate",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-bronchodilatortest"
      }
    }],
    "linkId" : "a-BronchodilatorTest",
    "text" : "applicability-BronchodilatorTest",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-hemoglobin"
      }
    }],
    "linkId" : "a-Hemoglobin",
    "text" : "applicability-Hemoglobin",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-secondtemperature"
      }
    }],
    "linkId" : "a-SecondTemperature",
    "text" : "applicability-SecondTemperature",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "a-fluidtest"
      }
    }],
    "linkId" : "a-FluidTest",
    "text" : "applicability-FluidTest",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.respiratoryrate"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-RespiratoryRate').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.RespiratoryRate",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{Breaths}/min"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE02').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty()"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().exists(), %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value,{})"
        }
      }],
      "linkId" : "Ccc.B22.DE01",
      "text" : "Respiratory Rate (breaths per minute)",
      "type" : "quantity",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE01-help",
        "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty() and %resource.repeat(item).where(linkId='force-collection').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE02",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE02",
          "display" : "Unable to perform Respiratory Rate at this time"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 2 and (%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value > 60 '{Breaths}/min' or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 60 '{Breaths}/min') and   %resource.repeat(item).where(linkId='Respiratory Rate Second Count Profile').answer.first().empty()"
        }
      }],
      "linkId" : "second",
      "type" : "group",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
          "valueCoding" : {
            "system" : "http://unitsofmeasure.org",
            "code" : "{Breaths}/min"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE04",
        "text" : "Respiratory Rate Second Count (breaths per minute)",
        "type" : "quantity",
        "required" : false,
        "repeats" : false,
        "item" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.org/fhir/questionnaire-item-control",
                "code" : "help"
              }]
            }
          }],
          "linkId" : "Ccc.B22.DE04-help",
          "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
          "type" : "display"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "check-box",
              "display" : "Check-box"
            }],
            "text" : "Check-box"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE05",
        "type" : "choice",
        "required" : false,
        "repeats" : true,
        "answerOption" : [{
          "valueCoding" : {
            "code" : "Ccc.B22.DE05",
            "display" : "Respiratory Rate Second Count Not Possible"
          }
        }]
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min')"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min'),iif(%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value<2 and (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().value >= 60 '{Breaths}/min' or (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists()  and ( %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value  >= 60 '{Breaths}/min'  or %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value  >= 60 '{Breaths}/min' ) ) ) or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 50 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 40 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value>=12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 60, true, false),{})"
        }
      }],
      "linkId" : "Ccc.B22.DE07",
      "text" : "Fast Breathing",
      "type" : "boolean",
      "required" : false,
      "repeats" : false,
      "readOnly" : true,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE07-help",
        "text" : "The number of breaths for <b>‘fast breathing’ depends on the child’s age.</b>   * Under 2 months: More than 60 breaths per minute* * 2 to 11 months: More than 50 breaths per minute * 12 to 59 months: More than 40 breaths per minute  *In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.fluidtest"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-FluidTest').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.FluidTest",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().empty() and ( %resource.repeat(item).where(linkId='oftrp').answer.empty()  or %resource.repeat(item).where(linkId='oftrp').answer.first().value=true )"
        }
      }],
      "linkId" : "Ccc.B22.DE08",
      "text" : "Oral Fluid Test Results",
      "type" : "choice",
      "required" : true,
      "repeats" : false,
      "answerOption" : [{
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE09",
          "display" : "Completely Unable to Drink"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE10",
          "display" : "Vomits Immediately / Everything"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE11",
          "display" : "Drinks Poorly"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE12",
          "display" : "Drinks Eagerly / Thirstily"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE13",
          "display" : "Drinks Normally"
        }
      }],
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE08-help",
        "text" : "If a child is unconscious do not try to carry out an oral fluid test (Exact wording <span class=\"caps\">TBC</span>) &#8211; Pop Up</p>\n\n\t<p>If a breastfeeding assessment and an Oral Fluid test is recommended for a child that is only breastfed then a pop up is required to ensure that the health care worker observes the signs for both and provides results for both tests. </p>\n\n\t<p>Oral Fluid Test<br />\nIf it is not possible to perform an oral fluid test, the health care worker should assume that the child is vomiting everything<br />\nFor a child under 6 months the health care worker can offer for the mother to breastfeed instead of receiving fluids</p>\n\n\t<p>Caution: Do not force fluids into an unconscious child , it can be dangerous. The fluid can cause them to choke or the fluid can go into their lungs. </p>\n\n\t<p>Pop up box to be made available with instructions on how to carry out an oral fluid test.<br />\nAdditional information <span class=\"caps\">TBC</span>",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE14",
      "type" : "choice",
      "required" : true,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE14",
          "display" : "Unable to Perform Oral Fluid Test"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B7.DE09').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B7.DE10').answer.first().value =  true"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().exists() and (%resource.repeat(item).where(linkId='DS').answer.first().value = true  or %resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.where(value.code='Ccc.B22.DE09').exists() or %resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE08').answer.where(value.code='Ccc.B22.DE10').exists() )"
        }
      }],
      "linkId" : "Ccc.B22.DE14a",
      "text" : "Completely Unable to Drink or Vomits Immediately / Everything",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE14').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B7.DE09').answer.first().value= false and %resource.repeat(item).where(linkId='Ccc.B7.DE10').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE15",
      "text" : "Has the Child had anything to drink today?",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.FluidTest').repeat(item).where(linkId='Ccc.B22.DE15').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B22.DE16",
      "text" : "How did the child last drink",
      "type" : "choice",
      "required" : false,
      "repeats" : false,
      "answerOption" : [{
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE09",
          "display" : "Completely Unable to Drink"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE10",
          "display" : "Vomits Immediately / Everything"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE11",
          "display" : "Drinks Poorly"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE12",
          "display" : "Drinks Eagerly / Thirstily"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE13",
          "display" : "Drinks Normally"
        }
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.bronchodilatortest"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-BronchodilatorTest').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.BronchodilatorTest",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BronchodilatorTest').repeat(item).where(linkId='Ccc.B22.DE22').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE17",
      "text" : "Inhaled Bronchodilator Trial Results",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE18",
          "display" : "Chest Indrawing (post inhaled bronchodilator trial)"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE19",
          "display" : "Respiratory Rate (post inhaled bronchodilator trial)"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE20",
          "display" : "Fast Breathing (post inhaled bronchodilator trial)"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE21",
          "display" : "No Fast Breathing and No Chest Indrawing (post Inhaled Bronchodilator Trial)"
        }
      },
      {
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B22.DE22",
          "display" : "Inhaled Bronchodilator Trial Not Feasible or Available"
        }
      }],
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE17-help",
        "text" : "Provide information on how to conduct an Inhaled Bronchodilator Trial as per <span class=\"caps\">IMCI</span> training &#8211; <span class=\"caps\">TBC</span>",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BronchodilatorTest').repeat(item).where(linkId='Ccc.B22.DE17').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE22",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE22",
          "display" : "Inhaled Bronchodilator Trial Not Feasible or Available"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      }],
      "linkId" : "Ccc.B22.DE21",
      "text" : "No Fast Breathing and No Chest Indrawing (post Inhaled Bronchodilator Trial)",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.breastfeeding"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-BreastFeedingTest').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.BreastFeeding",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "linkId" : "Ccc.B22.DE27",
      "text" : "Breastfeeding Assessment",
      "type" : "display",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE27-help",
        "text" : "If a breastfeeding assessment and an Oral Fluid test is recommended for a child that is only breastfed then a pop up is required to ensure that the health care worker observes the signs for both and provides results for both tests.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      }],
      "linkId" : "Ccc.B22.DE41",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE41",
          "display" : "Breastfeeding Assessment Not Possible"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      }],
      "linkId" : "Ccc.B22.DE28",
      "text" : "Breastfed in the previous hour",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE28').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.B22.DE29",
      "text" : "Mother able to wait until young infant is willing to breastfeed again",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE30",
      "text" : "Mother reports difficulty breastfeeding",
      "type" : "boolean",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE30-help",
        "text" : "Provide information on what difficulty breastfeeding may include, such as: the infant feeds too often, doesn&#8217;t feed often enough, she does not have enough milk, her nipples are sore, or she has flat or inverted nipples. After feeds, the infant may be restless, cry or try to suckle again, or continue to breastfeed for a long time.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE31",
      "text" : "Chin Touching Breast",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE32",
      "text" : "Mouth Wide Open",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE33",
      "text" : "Lower Lip Turned Outwards",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE34",
      "text" : "More Areola Visible above than below the Mouth",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE41').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE35",
      "text" : "Slow Deep Sucks, Sometimes Pausing",
      "type" : "boolean",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE40').answer.first().exists() and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE35').answer.first().exists() and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE31').answer.first().exists() and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE32').answer.first().exists() and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE33').answer.first().exists()  and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE34').answer.first().exists()"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE37').answer.first().value=true,'Not well Attached to Breast',iif(  %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE38').answer.first().value=true , 'Good Attachment',iif(  %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE39').answer.first().value=true,'Not Sucking Effectively',iif( %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE40').answer.first().value=true, 'Sucking Effectively',{}))))"
        }
      }],
      "linkId" : "Ccc.B22.DE36",
      "text" : "Breastfeeding Assessment Results",
      "type" : "string",
      "required" : true,
      "repeats" : false,
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE31').answer.first().value = false or %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE32').answer.first().value = false or %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE33').answer.first().value = false or %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE34').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE37",
      "text" : "Not well Attached to Breast",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE31').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE32').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE33').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE34').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B22.DE38",
      "text" : "Good Attachment",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE35').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE39",
      "text" : "Not Sucking Effectively",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE35').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B22.DE40",
      "text" : "Sucking Effectively",
      "type" : "boolean",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE30').answer.first().value = true"
        }
      }],
      "linkId" : "Ccc.B22.DE42",
      "text" : "Difficulty Breastfeeding Reported",
      "type" : "boolean",
      "required" : false,
      "repeats" : false,
      "readOnly" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE39').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B22.BreastFeeding').repeat(item).where(linkId='Ccc.B22.DE37').answer.first().value =true"
        }
      }],
      "linkId" : "Ccc.B22.DE44",
      "text" : "Difficulty Breastfeeding Observed",
      "type" : "boolean",
      "required" : false,
      "repeats" : false,
      "readOnly" : true
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.hemoglobin"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-Hemoglobin').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.Hemoglobin",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.Hemoglobin').repeat(item).where(linkId='Ccc.B22.DE82').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE81",
      "text" : "Hemoglobin (Hb) g/dL",
      "type" : "quantity",
      "required" : true,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.Hemoglobin').repeat(item).where(linkId='Ccc.B22.DE81').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE82",
      "type" : "choice",
      "required" : true,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE82",
          "display" : "Hemoglobin Test Not Available"
        }
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.secondtemperature"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='a-SecondTemperature').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.SecondTemperature",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "Cel"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE46').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE47",
      "text" : "Axillary Temperature (second measurement)",
      "type" : "quantity",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE47-help",
        "text" : "The client&#8217;s axillary temperature in degrees Celcius (temperature taken under the armpit)<br />\nWarning/error if above 45 and below 32 degrees Celcius.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B22.DE46",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE46",
          "display" : "Second Temperature Measurement Not Feasible"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().exists()"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().value >= 38.5 'Cel' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2, '2',iif(%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().value >= 38 'Cel' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value< 2 or %resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().value >= 37.5 'Cel' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2, 'High',iif(%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().value < 35.5 'Cel' , 'Low',iif(%resource.repeat(item).where(linkId='Ccc.B22.SecondTemperature').repeat(item).where(linkId='Ccc.B22.DE47').answer.first().value.exists(), 'Normal',{}))))"
        }
      }],
      "linkId" : "Ccc.B22.DE50",
      "text" : "Measured Temperature (second measurement)",
      "type" : "string",
      "required" : false,
      "repeats" : false,
      "readOnly" : true
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "(( %resource.repeat(item).where(linkId='a-RespiratoryRate').answer.empty()  or %resource.repeat(item).where(linkId='a-RespiratoryRate').answer.first().value=false ) ) and( ( %resource.repeat(item).where(linkId='a-FluidTest').answer.empty()  or %resource.repeat(item).where(linkId='a-FluidTest').answer.first().value=false ) ) and ( ( %resource.repeat(item).where(linkId='a-BronchodilatorTest').answer.empty()  or %resource.repeat(item).where(linkId='a-BronchodilatorTest').answer.first().value=false ) ) and (( %resource.repeat(item).where(linkId='a-BreastFeedingTest').answer.empty()  or %resource.repeat(item).where(linkId='a-BreastFeedingTest').answer.first().value=false ) ) and ( ( %resource.repeat(item).where(linkId='a-Hemoglobin').answer.empty()  or %resource.repeat(item).where(linkId='a-Hemoglobin').answer.first().value=false ) ) and (( %resource.repeat(item).where(linkId='a-SecondTemperature').answer.empty()  or %resource.repeat(item).where(linkId='a-SecondTemperature').answer.first().value=false ) )"
      }
    }],
    "linkId" : "notesttodo",
    "text" : "No assessments / tests to do",
    "type" : "display",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate profile"
      }
    }],
    "linkId" : "Respiratory Rate profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate second count profile"
      }
    }],
    "linkId" : "Respiratory Rate Second Count Profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "fast breathing profile"
      }
    }],
    "linkId" : "Fast Breathing profile",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ds"
      }
    }],
    "linkId" : "DS",
    "text" : "Danger Signs",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b7.de09"
      }
    }],
    "linkId" : "Ccc.B7.DE09",
    "text" : "Not able to drink or breastfeed",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b7.de10"
      }
    }],
    "linkId" : "Ccc.B7.DE10",
    "text" : "Vomiting Everything",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "now()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    }],
    "linkId" : "timestamp",
    "type" : "dateTime",
    "required" : false
  }]
}

```
