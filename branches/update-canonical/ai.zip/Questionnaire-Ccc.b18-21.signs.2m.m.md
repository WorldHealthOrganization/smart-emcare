# Ccc.B18-21.Signs.2m.m - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ccc.B18-21.Signs.2m.m**

## Questionnaire: Ccc.B18-21.Signs.2m.m
Branch:



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "Ccc.b18-21.signs.2m.m",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-targetStructureMap",
    "valueCanonical" : "https://smart.who.int/ccc/StructureMap/Ccc.b18-21.signs.2m.m"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://smart.who.int/ccc/Library/Cccb1821signs2mm"
  }],
  "url" : "https://smart.who.int/ccc/Questionnaire/Ccc.b18-21.signs.2m.m",
  "version" : "0.1.0",
  "name" : "Ccc.B18-21.Signs.2m.m",
  "title" : "Ccc.B18-21.Signs.2m.m",
  "status" : "active",
  "experimental" : false,
  "subjectType" : ["Patient"],
  "date" : "2026-04-07T13:42:05+00:00",
  "publisher" : "World Health Organization (WHO)",
  "contact" : [{
    "name" : "World Health Organization (WHO)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  },
  {
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "fever"
      }
    }],
    "linkId" : "Fever",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Fever-help",
      "text" : "The client is reported to have or has had fever",
      "type" : "display"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-displayCategory",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-display-category",
            "code" : "instructions"
          }]
        }
      }],
      "linkId" : "Fever-instruction",
      "text" : "help",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "zscore"
      }
    }],
    "linkId" : "zscore",
    "type" : "decimal",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageinmonths"
      }
    }],
    "linkId" : "AgeInMonths",
    "text" : "Age in Month",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageindays"
      }
    }],
    "linkId" : "AgeInDays",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b20s1.de01"
      }
    }],
    "linkId" : "Ccc.B20S1.DE01",
    "text" : "Diarrhoea",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.a.de31"
      }
    }],
    "linkId" : "Ccc.A.DE31",
    "text" : "Biological Mother Vital Status",
    "type" : "choice",
    "required" : false,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.A.DE46",
        "display" : "Dead"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.A.DE34",
        "display" : "Alive"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.A.DE33",
        "display" : "Unknown"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b21s1.de01"
      }
    }],
    "linkId" : "Ccc.B21S1.DE01",
    "text" : "Breastfed",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b18s1.de02"
      }
    }],
    "linkId" : "Ccc.B18S1.DE02",
    "text" : "Difficulty with Feeding",
    "type" : "choice",
    "required" : false,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S1.DE03",
        "display" : "Not Able to Feed At All"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S1.DE04",
        "display" : "Not Feeding Well"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S1.DE05",
        "display" : "Feeding Well"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "yi_sever_but_dhey"
      }
    }],
    "linkId" : "YI_sever_but_dhey",
    "text" : "YI severe classification other than severe dehydration",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "yi_sever"
      }
    }],
    "linkId" : "YI_sever",
    "text" : "YI severe classification",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "Ccc.b7.de03"
      }
    }],
    "linkId" : "Ccc.B7.DE03",
    "text" : "Convulsion(s) in this Illness",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.respiratoryrate"
    }],
    "linkId" : "Ccc.B22.RespiratoryRate",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{Breaths}/min"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE02').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty()"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().exists(), %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value,{})"
        }
      }],
      "linkId" : "Ccc.B22.DE01",
      "text" : "Respiratory Rate (breaths per minute)",
      "type" : "quantity",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE01-help",
        "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty() and %resource.repeat(item).where(linkId='force-collection').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE02",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE02",
          "display" : "Unable to perform Respiratory Rate at this time"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 2 and (%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value > 60 '{Breaths}/min' or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 60 '{Breaths}/min') and   %resource.repeat(item).where(linkId='Respiratory Rate Second Count Profile').answer.first().empty()"
        }
      }],
      "linkId" : "second",
      "type" : "group",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
          "valueCoding" : {
            "system" : "http://unitsofmeasure.org",
            "code" : "{Breaths}/min"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE04",
        "text" : "Respiratory Rate Second Count (breaths per minute)",
        "type" : "quantity",
        "required" : false,
        "repeats" : false,
        "item" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.org/fhir/questionnaire-item-control",
                "code" : "help"
              }]
            }
          }],
          "linkId" : "Ccc.B22.DE04-help",
          "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
          "type" : "display"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "check-box",
              "display" : "Check-box"
            }],
            "text" : "Check-box"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE05",
        "type" : "choice",
        "required" : false,
        "repeats" : true,
        "answerOption" : [{
          "valueCoding" : {
            "code" : "Ccc.B22.DE05",
            "display" : "Respiratory Rate Second Count Not Possible"
          }
        }]
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min')"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min'),iif(%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value<2 and (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().value >= 60 '{Breaths}/min' or (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists()  and ( %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value  >= 60 '{Breaths}/min'  or %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value  >= 60 '{Breaths}/min' ) ) ) or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 50 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 40 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value>=12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 60, true, false),{})"
        }
      }],
      "linkId" : "Ccc.B22.DE07",
      "text" : "Fast Breathing",
      "type" : "boolean",
      "required" : false,
      "repeats" : false,
      "readOnly" : true,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE07-help",
        "text" : "The number of breaths for <b>‘fast breathing’ depends on the child’s age.</b>   * Under 2 months: More than 60 breaths per minute* * 2 to 11 months: More than 50 breaths per minute * 12 to 59 months: More than 40 breaths per minute  *In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B18S2.DE07",
    "text" : "Severe Chest Indrawing",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B18S2.DE07-help",
      "text" : "The young infant must be calm while you assess for severe chest indrawing.  Lift the young infant’s shirt. </p>\n\n\t<p>Look for chest indrawing when the young infant breathes in. Lower chest wall indrawing is the inward movement of the bony structure of the chest wall <br />\nwhen the child breathes in. Look at the lower chest wall (lower ribs). The child has chest indrawing if the lower chest wall goes IN when the child breathes IN.<br />\nIn normal breathing, the whole chest wall (upper and lower) and the abdomen move <span class=\"caps\">OUT</span> when the child breathes IN. </p>\n\n\t<p>Mild chest indrawing is normal in a young infant because the chest wall is soft. Severe chest indrawing is very deep and easy to see.",
      "type" : "display"
    }]
  },
  {
    "linkId" : "Ccc.B18S2.DE08",
    "text" : "Movements",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S2.DE11",
        "display" : "Moves on his or her own or moves spontaneously or without stimulation"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S2.DE10",
        "display" : "Movement only when stimulated but then stops"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B18S2.DE09",
        "display" : "No movement at all"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B18S2.DE08-help",
      "text" : "Look at the young infant’s movements. Does the young infant move on his/her own? Does the infant move only when stimulated but then stops? Does the infant not move at all?<br />\nYoung infants often sleep most of the time, and this is not a sign of illness. It is not necessary for the infant to be awake if he/she is moving spontaneously. <br />\nIf a young infant is not moving spontaneously and does not wake up during the assessment, ask the mother to wake him. An awake young infant will normally move his arms or legs or turn his head several times in a  minute if you watch him closely. If the infant is awake but has no spontaneous movements, gently stimulate the young infant. Stimulation  is a gentle, painless touching of the baby with enough pressure that would evoke movements, sound making and eye opening. The presence of any movement such as a grimace of the face, eye-opening or movement of a limb will qualify &#8220;Movement only when stimulated but then stops&#8221;.  An infant who cannot be woken up even after stimulation is considered to have the sign &#8220;Does not move even with stimulation. &#8220; ",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B18S2.DE12",
    "text" : "Umbilicus Red or Pus Draining",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B18S2.DE12-help",
      "text" : "&#8220;The umbilical cord usually separates one week after birth and the wound heals within 15 days.  Redness of the end of the umbilicus or pus draining from the umbilicus are signs of umbilical  infection.&#8221; ",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B18S2.DE13",
    "text" : "Skin Pustules",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B18S2.DE13-help",
      "text" : "Examine the skin on the entire body. Skin pustules are red spots or blisters which contain pus.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B19S2.DE01",
    "text" : "Yellow Skin",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B19S2.DE01-help",
      "text" : "Jaundice is a yellow discoloration of skin and mucus membranes. It is important to look for jaundice in natural light. To look for jaundice, press the  infant’s skin over the forehead with your fingers to blanch, remove your fingers and look for yellow discolouration. If there is yellow discoloration, the infant has jaundice",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B19S2.DE02",
    "text" : "Yellow Palms or Yellow Soles",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B19S2.DE02-help",
      "text" : "Jaundice is a yellow discoloration of skin and mucus membranes. Jaundice in the palms of hands or soles of feet is a sign of Severe Jaundice.  It is important to look for jaundice in natural light. To assess for severe jaundice, press the infant&#8217;s skin in the palm of there hand and then in the sole of their feet with your fingers to blanch, remove your finders and look for yellow dicoulouration in the palm or the sole. If there is yellow discoloration of the palm or sole, the infant has severe jaundice.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='AgeInDays').answer.first().value >1 and  %resource.repeat(item).where(linkId='Ccc.B19S2.DE01').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B19S2.DE02').answer.first().value = false and  %resource.repeat(item).where(linkId='AgeInDays').answer.first().value < 21"
      }
    }],
    "linkId" : "Ccc.B19S2.DE04",
    "text" : "When did the Jaundice first appear?",
    "type" : "choice",
    "required" : false,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B19S2.DE05",
        "display" : "Within less than 24 hours of birth"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B19S2.DE06",
        "display" : "24 hours or more after birth"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B19S2.DE07",
        "display" : "Unknown when Jaundice first appeared"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B19S2.DE04-help",
      "text" : "Ask the caregiver when the baby&#8217;s skin first turned yellowish. If the caregiver didn&#8217;t notice the yellow discolouration or can&#8217;t remember when it started, select &#8220;don&#8217;t know&#8221;. <br />\nJaundice that appears in less than 24 hours after birth is always due to an underlying disease. These babies should be referred urgently. <br />\nMany normal babies, particularly small babies, may have jaundice during the first week of life. This jaundice usually appears on the third or fourth day of life and is mild and disappears before the age of two to  three weeks. It does not need any treatment.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B20S1.DE01').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B11S2.DE01",
    "text" : "Sunken Eyes",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE01-help",
      "text" : "The eyes of a dehydrated infant may look sunken. In a low-weight infant, the eyes may always look sunken, even if the young infant is not dehydrated. Even though the sign “sunken eyes” is less reliable in a low-weight infant, it can still be used to classify the young infant‘s dehydration. </p>\n\n\t<p>Decide if you think the eyes are sunken. Then ask the mother if she thinks her child’s eyes look unusual. Her opinion can help you confirm.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B20S1.DE01').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B11S2.DE02",
    "text" : "Skin pinch of Abdomen",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE03",
        "display" : "Skin Pinch goes back very slowly (More than 2 seconds)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE04",
        "display" : "Skin Pinch goes back slowly (2 seconds or fewer, but not immediately)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE05",
        "display" : "Skin Pinch goes back Normally (immediately)"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE02-help",
      "text" : "Locate the area on the infant’s abdomen halfway between the umbilicus and the side of the abdomen. To do the skin pinch, use your thumb and first finger. Do not use your fingertips because this will cause pain. Place <br />\nyour hand so that when you pinch the skin, the fold of skin will be in a line up and down the child’s body and not across the child’s <br />\nbody. Firmly pick up all of the layers of skin and the tissue under them. Pinch the skin for <br />\none second and then release it. When you release the skin, look to see if the skin pinch <br />\ngoes back:</p>\n\n\t<p>• very slowly (longer than 2 seconds)<br />\n• slowly<br />\n• immediately<br />\nIf the skin stays up for even a brief time after you release it, decide that the skin pinch goes back slowly",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B20S1.DE01').answer.first().value = true and %resource.repeat(item).where(linkId='Ccc.B18S2.DE08').answer.first().value.code  = 'Ccc.B18S2.DE11'"
      }
    }],
    "linkId" : "Ccc.B11S2.DE06",
    "text" : "Restless and Irritable",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE06-help",
      "text" : "Look at the young infant&#8217;s general condition Is the infant restles and irritable? <br />\nAn infant has teh sign &#8220;restless and irritable&#8221; if the infant is restless and irritable all the time or every time he is touched and handled. If an infant is calm when breastfeeding but again <br />\nrestless and irritable when he stops breastfeeding, he has the sign “restless and irritable”. A healthy infant will be consoled when put on the breast.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='zscore').answer.first().exists()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "iif(%resource.repeat(item).where(linkId='zscore').answer.first().exists(), iif( %resource.repeat(item).where(linkId='zscore').answer.first().value >= (-2.0), 'Normal Weight for Age', iif( %resource.repeat(item).where(linkId='zscore').answer.first().value < (-3.0), 'Very Low Weight for Age','Low Weight for Age')), {})"
      }
    }],
    "linkId" : "Ccc.B21S2.DE01",
    "text" : "Weight Status",
    "type" : "string",
    "required" : false,
    "repeats" : false,
    "readOnly" : true,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE01-help",
      "text" : "Weight status is calculated based on the young infant&#8217;s weight for age Z-score, which is determined from a standardized chart for weight -for-age for the infant&#8217;s sex. <br />\nA young infant is low weight for age if the z-score is below -2. <br />\nA young infant who is less than 7 days old and weighs less than 2 kg is considered very low weight.<br />\nSome young infants who are low weight for age were born with low birth weight. Some did not gain weight well after birth.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value = true and ( %resource.repeat(item).where(linkId='YI_sever_but_dhey').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever_but_dhey').answer.first().value=false )"
      }
    }],
    "linkId" : "Ccc.B21S2.DE05",
    "text" : "Breastfed how many times in 24 hours?",
    "type" : "integer",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE05-help",
      "text" : "Ask the caregiver how many times in 24 hours (one day and one night) they usually breastfeed the young infant. The recommendation is that the young infant be breastfed as often and for as long as the <br />\ninfant wants, day and night. This should be 8 or more times in 24 hours.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S2.DE05').answer.first().value>= 8"
      }
    }],
    "linkId" : "Ccc.B21S2.DE06",
    "text" : "Sufficient feeds",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value = true and ( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false )"
      }
    }],
    "linkId" : "Ccc.B21S2.DE08",
    "text" : "Young Infant receives food or fluids other than breast milk",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE08-help",
      "text" : "Find out if the young infant is receiving any other foods or drinks such as other milk, juice, tea, thin porridge, dilute cereal, or even water. Ask how often he receives it and the amount. You need to know if the infant is mostly breastfed, or mostly fed on other foods",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/questionnaire-item-control",
          "code" : "check-box",
          "display" : "Check-box"
        }],
        "text" : "Check-box"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value= false and ( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false ) and ( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false )"
      }
    }],
    "linkId" : "Ccc.B21S2.DE09",
    "text" : "What milk is being given as a replacement feed?",
    "type" : "choice",
    "required" : true,
    "repeats" : true,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE11",
        "display" : "Inappropriate replacement milk"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE10",
        "display" : "Appropriate replacement milk"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE09-help",
      "text" : "Ask the mother questions to determine what replacement milk or milks are used. It may be a breastmilk replacement, animal milk or some other fluid or some combination. Determine if this type of replacement feed is appropriate or not appropriate in your setting.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value= false"
      }
    }],
    "linkId" : "Ccc.B21S2.DE12",
    "text" : "How many replacement feeds during the day and night (24 hours)?",
    "type" : "integer",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE12-help",
      "text" : "A young infant up to one month of age should be fed 8 times and a young infant between 1 <br />\nand 2 months of age should be fed 7 times in 24 hours.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S2.DE12').answer.first().value>=8"
      }
    }],
    "linkId" : "Ccc.B21S2.DE13",
    "text" : "Sufficient replacement feeds (in 24 hours)",
    "type" : "boolean",
    "required" : true,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
      "valueCoding" : {
        "system" : "http://unitsofmeasure.org",
        "code" : "ml"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value= false"
      }
    }],
    "linkId" : "Ccc.B21S2.DE15",
    "text" : "How much milk is given at each feed (ml)?",
    "type" : "quantity",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE15-help",
      "text" : "A young infant up to one month of age should be given approximately 60 ml per feed, 8 times per day, and a young infant between 1 and 2 months of age approximately 90 ml at each feed, 7 times per day. It is helpful to have common bottles or cups available so that a mother can show you the amount that she gives.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "iif(%resource.repeat(item).where(linkId='AgeInDays').answer.first().value < 29, %resource.repeat(item).where(linkId='Ccc.B21S2.DE15').answer.first().value>=60 'ml', %resource.repeat(item).where(linkId='Ccc.B21S2.DE15').answer.first().value>=90 'ml' )"
      }
    }],
    "linkId" : "Ccc.B21S2.DE16",
    "text" : "Sufficient replacement feeds",
    "type" : "boolean",
    "required" : true,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value= false"
      }
    }],
    "linkId" : "Ccc.B21S2.DE18",
    "text" : "How is the milk prepared?",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE19",
        "display" : "Correct and hygienic feed preparation"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE20",
        "display" : "Incorrect or unhygienic feed preparation"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE18-help",
      "text" : "Let mother demonstrate or explain how a feed is prepared and how she gives it to the infant. Determine if the breastmilk substitute is being prepared correctly and hygienically.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S2.DE08').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value = false"
      }
    }],
    "linkId" : "Ccc.B21S2.DE21",
    "text" : "How is the milk given?",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE22",
        "display" : "Cup"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE23",
        "display" : "Bottle"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S2.DE08').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value = false"
      }
    }],
    "linkId" : "Ccc.B21S2.DE24",
    "text" : "How are the feeding utensils cleaned?",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE26",
        "display" : "Feeding utensils not cleaned hygienically"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE25",
        "display" : "Feeding utensils cleaned hygienically"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE24-help",
      "text" : "Ask the caregiver how they clear the feeding utensils. Determine if this is a safe and hygienic cleaning method.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B21S1.DE01').answer.first().value = false and ( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false )"
      }
    }],
    "linkId" : "Ccc.B21S2.DE27",
    "text" : "Do you give any breastmilk at all?",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE28",
        "display" : "Breastmilk also given"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B21S2.DE29",
        "display" : "No Breastmilk at all"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false ) and %resource.repeat(item).where(linkId='Ccc.B21S2.DE31').answer.first().empty()"
      }
    }],
    "linkId" : "Ccc.B21S2.DE30",
    "text" : "Ulcers or White Patches in Mouth",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B21S2.DE30-help",
      "text" : "Look inside the mouth at the tongue and inside of the cheek. Thrush looks like milk curds on the inside of the cheek, or a thick white coating of the tongue. Try to wipe the white off. The white patches of thrush will remain.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/questionnaire-item-control",
          "code" : "check-box",
          "display" : "Check-box"
        }],
        "text" : "Check-box"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "( %resource.repeat(item).where(linkId='YI_sever').answer.empty()  or %resource.repeat(item).where(linkId='YI_sever').answer.first().value=false ) and %resource.repeat(item).where(linkId='Ccc.B21S2.DE30').answer.first().empty()"
      }
    }],
    "linkId" : "Ccc.B21S2.DE31",
    "type" : "choice",
    "required" : false,
    "repeats" : true,
    "answerOption" : [{
      "valueCoding" : {
        "code" : "Ccc.B21S2.DE31",
        "display" : "Unable to check if Ulcers or White Patches in Mouth"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate profile"
      }
    }],
    "linkId" : "Respiratory Rate profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "force-collection"
      }
    }],
    "linkId" : "force-collection",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate second count profile"
      }
    }],
    "linkId" : "Respiratory Rate Second Count Profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "fast breathing profile"
      }
    }],
    "linkId" : "Fast Breathing profile",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "now()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    }],
    "linkId" : "timestamp",
    "type" : "dateTime",
    "required" : false
  }]
}

```
