# Ccc.B10-16.Signs.2m.p - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ccc.B10-16.Signs.2m.p**

## Questionnaire: Ccc.B10-16.Signs.2m.p
Branch:



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "Ccc.b10-16.signs.2m.p",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-targetStructureMap",
    "valueCanonical" : "https://smart.who.int/ccc/StructureMap/Ccc.b10-16.signs.2m.p"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://smart.who.int/ccc/Library/Cccb1016signs2mp"
  }],
  "url" : "https://smart.who.int/ccc/Questionnaire/Ccc.b10-16.signs.2m.p",
  "version" : "0.1.0",
  "name" : "Ccc.B10-16.Signs.2m.p",
  "title" : "Ccc.B10-16.Signs.2m.p",
  "status" : "active",
  "experimental" : false,
  "subjectType" : ["Patient"],
  "date" : "2026-04-07T13:42:05+00:00",
  "publisher" : "World Health Organization (WHO)",
  "contact" : [{
    "name" : "World Health Organization (WHO)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  },
  {
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "danger signs"
      }
    }],
    "linkId" : "Danger Signs",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageinmonths"
      }
    }],
    "linkId" : "AgeInMonths",
    "text" : "Age",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "cough"
      }
    }],
    "linkId" : "Cough",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "difficulty breathing"
      }
    }],
    "linkId" : "Difficulty Breathing",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "oral fluid test failed"
      }
    }],
    "linkId" : "Oral Fluid Test failed",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "diarrhoea"
      }
    }],
    "linkId" : "Diarrhoea",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "not able to drink or breastfeed"
      }
    }],
    "linkId" : "Not able to drink or breastfeed",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "unconscious or lethargic"
      }
    }],
    "linkId" : "Unconscious or Lethargic",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "fever"
      }
    }],
    "linkId" : "Fever",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ear problem"
      }
    }],
    "linkId" : "Ear Problem",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "eye problem"
      }
    }],
    "linkId" : "Eye Problem",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "skin problem"
      }
    }],
    "linkId" : "Skin Problem",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ear discharge"
      }
    }],
    "linkId" : "Ear discharge",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ear discharge for how long?"
      }
    }],
    "linkId" : "Ear discharge for how long?",
    "type" : "choice",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "itchy skin"
      }
    }],
    "linkId" : "Itchy Skin",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-subQuestionnaire",
      "valueCanonical" : "https://smart.who.int/ccc/Questionnaire/Ccc.b22.respiratoryrate"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Difficulty Breathing').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B22.RespiratoryRate",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "{Breaths}/min"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE02').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty()"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().exists(), %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value,{})"
        }
      }],
      "linkId" : "Ccc.B22.DE01",
      "text" : "Respiratory Rate (breaths per minute)",
      "type" : "quantity",
      "required" : true,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE01-help",
        "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().empty() and %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().empty() and %resource.repeat(item).where(linkId='force-collection').answer.first().value = false"
        }
      }],
      "linkId" : "Ccc.B22.DE02",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B22.DE02",
          "display" : "Unable to perform Respiratory Rate at this time"
        }
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 2 and (%resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value > 60 '{Breaths}/min' or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 60 '{Breaths}/min') and   %resource.repeat(item).where(linkId='Respiratory Rate Second Count Profile').answer.first().empty()"
        }
      }],
      "linkId" : "second",
      "type" : "group",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
          "valueCoding" : {
            "system" : "http://unitsofmeasure.org",
            "code" : "{Breaths}/min"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE04",
        "text" : "Respiratory Rate Second Count (breaths per minute)",
        "type" : "quantity",
        "required" : false,
        "repeats" : false,
        "item" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
            "valueCodeableConcept" : {
              "coding" : [{
                "system" : "http://hl7.org/fhir/questionnaire-item-control",
                "code" : "help"
              }]
            }
          }],
          "linkId" : "Ccc.B22.DE04-help",
          "text" : "<b>Count the number of breaths the child takes per minute</b> to determine if fast breathing is present.<br />\nIt is <b>very important that the child is calm</b> and still. If the child is moving or crying, you will not be able to get an accurate count of breaths. <br />\n<b>To count the breaths per minute,</b> use a watch with a second hand or a digital watch. Look for the breathing movement anywhere on the child’s chest or abdomen. <br />\nThe number of breaths for <b>‘fast breathing’ depends on the child’s age.</b></p>\n\n\t<ul>\n\t\t<li>Under 2 months: More than 60 breaths per minute*</li>\n\t\t<li>2 to 11 months: More than 50 breaths per minute</li>\n\t\t<li>12 to 59 months: More than 40 breaths per minute</li>\n\t</ul>\n\n\t<p>*In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
          "type" : "display"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "check-box",
              "display" : "Check-box"
            }],
            "text" : "Check-box"
          }
        },
        {
          "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
          "valueExpression" : {
            "language" : "text/fhirpath",
            "expression" : "%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().empty()"
          }
        }],
        "linkId" : "Ccc.B22.DE05",
        "type" : "choice",
        "required" : false,
        "repeats" : true,
        "answerOption" : [{
          "valueCoding" : {
            "code" : "Ccc.B22.DE05",
            "display" : "Respiratory Rate Second Count Not Possible"
          }
        }]
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
        "valueCode" : "horizontal"
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min')"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "iif(%resource.repeat(item).where(linkId='Fast Breathing profile').answer.first().empty() and (%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2 or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists() or  %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value < 60 '{Breaths}/min'),iif(%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value<2 and (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE04').answer.first().value >= 60 '{Breaths}/min' or (%resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='second').repeat(item).where(linkId='Ccc.B22.DE05').answer.first().exists()  and ( %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value  >= 60 '{Breaths}/min'  or %resource.repeat(item).where(linkId='Respiratory Rate profile').answer.first().value  >= 60 '{Breaths}/min' ) ) ) or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 50 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value >= 2or %resource.repeat(item).where(linkId='Ccc.B22.RespiratoryRate').repeat(item).where(linkId='Ccc.B22.DE01').answer.first().value >= 40 '{Breaths}/min' and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value>=12 and %resource.repeat(item).where(linkId='AgeInMonths').answer.first().value < 60, true, false),{})"
        }
      }],
      "linkId" : "Ccc.B22.DE07",
      "text" : "Fast Breathing",
      "type" : "boolean",
      "required" : false,
      "repeats" : false,
      "readOnly" : true,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B22.DE07-help",
        "text" : "The number of breaths for <b>‘fast breathing’ depends on the child’s age.</b>   * Under 2 months: More than 60 breaths per minute* * 2 to 11 months: More than 50 breaths per minute * 12 to 59 months: More than 40 breaths per minute  *In young infants, a second measurement should be taken to confirm, unless there is already another sign of possible serious bacterial infection",
        "type" : "display"
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Difficulty Breathing').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B10S2.DE03",
    "text" : "Chest Indrawing",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B10S2.DE03-help",
      "text" : "<b><span class=\"caps\">NORMAL</span>:</b> When child breaths <b>IN,</b> chest wall moves <b><span class=\"caps\">OUT</span></b><br />\n<b><span class=\"caps\">CHEST</span> <span class=\"caps\">INDRAWING</span>:</b> When child breaths <b>IN,</b> chest wall moves <b>IN</b></p>\n\n\t<p>Chest indrawing occurs when the child needs to make a greater effort than normal to breathe in. <b>You will look for chest indrawing when the child breathes IN.</b></p>\n\n\t<p>In normal breathing, the whole chest wall (upper and lower) and the abdomen move <span class=\"caps\">OUT</span> when the child breathes IN. <b>The child has chest indrawing if the lower chest wall (lower ribs) goes IN when the child breathes IN.</b>",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Difficulty Breathing').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B10S2.DE04",
    "text" : "Stridor in a calm child",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B10S2.DE04-help",
      "text" : "<b>Stridor is a harsh noise made when a child breathes IN.</b><br />\nPut your ear near the child’s mouth because stridor can be difficult to hear. Sometimes you will hear a wet noise if the child’s nose is blocked. Clear the nose, and listen again.</p>\n\n\t<p><b>Be sure to look and listen for stridor when the child is calm.</b><br />\nA child who is not very ill may have stridor only when he is crying or upset. However, a child who is calm and also has stridor has a dangerous situation.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Difficulty Breathing').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B10S2.DE05",
    "text" : "Wheezing",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B10S2.DE05-help",
      "text" : "<b>Wheeze is a high-pitched whistling or musical sound heard at the end of the breathing <span class=\"caps\">OUT</span>.</b> The child’s small air passages narrow to cause wheezing.<br />\n<b>To hear wheezing,</b> put your ear near to the child’s mouth when the child is calm. Look at the child’s breathing while you listen to check that the sound mainly occurs when the child breathes out",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B10S2.DE05').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B10S2.DE06",
    "text" : "Recurrent Wheeze",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B10S2.DE06-help",
      "text" : "Recurrent wheezing can be a sign of asthma, tuberculosis or other important health problems which require further assessment",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "(%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Difficulty Breathing').answer.first().value = true ) and  %resource.repeat(item).where(linkId='Ccc.B10S2.DE04').answer.first().value = false"
      }
    }],
    "linkId" : "Oxygen_Saturation",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-unit",
        "valueCoding" : {
          "system" : "http://unitsofmeasure.org",
          "code" : "%"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Oxygen_Saturation').repeat(item).where(linkId='Ccc.B10S2.DE09').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B10S2.DE07",
      "text" : "Oxygen Saturation",
      "type" : "quantity",
      "required" : false,
      "repeats" : false,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B10S2.DE07-help",
        "text" : "If pulse oximeter is available, determine oxygen saturation (SpO2). <br />\nAfter turning on, position the appropriate probe based on the child&#8217;s size. If using on a finger or toe, make sure the area is clean and without nail varnish. <b>Ensure that a good (even) pulse signal (waveform) is displayed before taking the reading.</b> If uncertain that the probe is working, check by testing on your own finger. <br />\n<b>Normal oxygen saturation at sea level is 95 &#8211; 100%. Oxygen should be given if saturation drops to less than 90%,</b> and may be needed for children with severe illness if SpO2 less than 94%. Different cut-offs may be used at high altitude.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Oxygen_Saturation').repeat(item).where(linkId='Ccc.B10S2.DE07').answer.first().exists() and %resource.repeat(item).where(linkId='Oxygen_Saturation').repeat(item).where(linkId='Ccc.B10S2.DE07').answer.first().value< 90 '%'"
        }
      }],
      "linkId" : "Ccc.B10S2.DE08",
      "text" : "Oxygen Saturation < 90 %",
      "type" : "display",
      "required" : false,
      "repeats" : false,
      "readOnly" : true,
      "item" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
          "valueCodeableConcept" : {
            "coding" : [{
              "system" : "http://hl7.org/fhir/questionnaire-item-control",
              "code" : "help"
            }]
          }
        }],
        "linkId" : "Ccc.B10S2.DE08-help",
        "text" : "Check that the value you have entered is correct. Children with oxygen saturation less than 90% need oxygen if available and urgent referral.",
        "type" : "display"
      }]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "check-box",
            "display" : "Check-box"
          }],
          "text" : "Check-box"
        }
      },
      {
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Oxygen_Saturation').repeat(item).where(linkId='Ccc.B10S2.DE07').answer.first().empty()"
        }
      }],
      "linkId" : "Ccc.B10S2.DE09",
      "type" : "choice",
      "required" : false,
      "repeats" : true,
      "answerOption" : [{
        "valueCoding" : {
          "code" : "Ccc.B10S2.DE09",
          "display" : "Oxygen saturation not measured"
        }
      }]
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Diarrhoea').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B11S2.DE01",
    "text" : "Sunken eyes",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE01-help",
      "text" : "<b>The eyes of a child who is dehydrated may look sunken.</b> Decide if you think the eyes are sunken. Then ask the mother if she thinks her child’s eyes look unusual. Her opinion can help<br />\nyou confirm.<br />\nNOTE: In a severely malnourished child who is wasted, the eyes may always look sunken, even if the child is not dehydrated. Still use the sign to classify dehydration.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Diarrhoea').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B11S2.DE02",
    "text" : "Skin pinch of Abdomen",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE03",
        "display" : "Skin Pinch goes back very slowly (More than 2 seconds)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE04",
        "display" : "Skin Pinch goes back slowly (2 seconds or fewer, but not immediately)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B20S2.DE05",
        "display" : "Skin Pinch goes back Normally (immediately)"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE02-help",
      "text" : "To assess dehydration using the skin pinch<br />\n1. <b><span class=\"caps\">ASK</span></b> the mother to place the child on the examining table so that the child is flat on his back with his arms at his sides (not over his head) and his legs straight. Or, ask the mother to hold the child so he is lying flat on her lap.<br />\n2. <b><span class=\"caps\">USE</span> <span class=\"caps\">YOUR</span> <span class=\"caps\">THUMB</span> <span class=\"caps\">AND</span> <span class=\"caps\">FIRST</span> <span class=\"caps\">FINGER</span></b> to locate the area on the child’s abdomen halfway between the umbilicus and the side of the abdomen. Do not use your fingertips because this will cause pain. The fold of the skin should be in a line up and down the child’s body.<br />\n3. <b><span class=\"caps\">PICK</span> UP</b> all the layers of skin and the tissue underneath them.<br />\n4. <b><span class=\"caps\">HOLD</span></b> the pinch for one second. Then release it.<br />\n5.. <b><span class=\"caps\">LOOK</span></b> to see if the skin pinch goes back <b>very slowly</b> (more than 2 seconds), <b>slowly,</b> (less than 2 seconds, but not immediately), or <b>immediately.</b> If the skin stays up for even a brief time after you release it, decide that the skin pinch goes back slowly.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Diarrhoea').answer.first().value = true and  iif(%resource.repeat(item).where(linkId='Unconscious or Lethargic').answer.first().value = true,false,true)"
      }
    }],
    "linkId" : "Ccc.B11S2.DE06",
    "text" : "Restless and Irritable",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B11S2.DE06-help",
      "text" : "A child is classified as restless and irritable if s/he is restless and irritable all the time or every time s/he is touched and handled. If an infant or child is calm when breastfeeding but again restless and irritable when he stops breastfeeding, s/he has the sign restless and irritable. Many children are upset just because they are in the clinic. Usually these children can be consoled and calmed, and do not have this sign.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    }],
    "linkId" : "Ccc.B17S1.DE01",
    "text" : "Throat problem",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B17S1.DE01-help",
      "text" : "Look to see if the child has a throat problem. <br />\n- Red (congested) throat indicates inflammation and may be sign of infection<br />\n- Exudate may be seen as white / yellow mucus on the tonsils or throat<br />\n- A membrane is a thick grey coating on the throat is a sign of diptheria, requiring urgent referral",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B17S1.DE01').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B17S1.DE02",
    "text" : "Specify Throat problem",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE03",
        "display" : "Red (congested) throat"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE04",
        "display" : "Exudate on Throat"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE05",
        "display" : "Membrane on throat"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "none",
        "display" : "None of the listed throat problems observed"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B17S1.DE02-help",
      "text" : "Look to see if the child has a throat problem. <br />\n- Red (congested) throat indicates inflammation and may be sign of infection<br />\n- Exudate may be seen as white / yellow mucus on the tonsils or throat<br />\n- A membrane is a thick grey coating on the throat is a sign of diptheria, requiring urgent referral",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B17S1.DE01').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B17S1.DE06",
    "text" : "Enlarged lymph nodes on front of neck",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B17S1.DE06-help",
      "text" : "Lymph nodes can be considered enlarged if 1cm or more in diameter (about the width of the tip of an adult index finger)",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B17S1.DE01').answer.first().value = true and %resource.repeat(item).where(linkId='Not able to drink or breastfeed').answer.first().value = false  or %resource.repeat(item).where(linkId='Not able to drink or breastfeed').answer.first().value = true and %resource.repeat(item).where(linkId='Oral Fluid Test failed').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B17S1.DE07",
    "text" : "Ability to swallow",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE08",
        "display" : "Yes, without difficulty"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE09",
        "display" : "Difficulty in swallowing"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B17S1.DE10",
        "display" : "Unable to swallow"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ear Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B13S2.DE01",
    "text" : "Tender swelling behind the ear",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B13S2.DE01-help",
      "text" : "<b>If both tenderness and swelling are present, the child may have mastoiditis, a deep infection in the mastoid bone.</b> Feel behind both ears. Compare them and decide if there is tender swelling of the mastoid bone. In infants, the swelling may be above the ear. Do not confuse this swelling of the bone with swollen lymph nodes.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ear Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B13S2.DE02",
    "text" : "Pus Seen Draining from the Ear",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B13S2.DE02-help",
      "text" : "Look inside the child’s ear to see if pus is draining. That is a sign of infection, even if the child is not feeling any pain. Draining pus is a sign of infection",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ear discharge').answer.first().value = false   and %resource.repeat(item).where(linkId='Ccc.B13S2.DE02').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B13S2.DE03",
    "text" : "Pus Seen Draining from the Ear for how long?",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B10S1.DE08",
        "display" : "14 days or more"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B10S1.DE07",
        "display" : "Less than 14 days"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B12S2.DE01",
    "text" : "Stiff neck",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B12S2.DE01-help",
      "text" : "<b>A stiff neck may be a sign of meningitis, cerebral malaria or another very severe febrile disease. It requires urgent treatment with injectable antibiotics and referral to a hospital.</b><br />\n<b><span class=\"caps\">WATCH</span> <span class=\"caps\">THE</span> <span class=\"caps\">CHILD</span>:</b> While you talk with the caregiver during the assessment, look to see if the child moves and bends his or her neck easily when looking around. If the child is moving and bending his or her neck, the child does not have a stiff neck.<br />\n<b><span class=\"caps\">TEST</span> <span class=\"caps\">THE</span> <span class=\"caps\">CHILD</span>:</b> If you did not see any movement, or if you are not sure, draw the child’s attention to his or her umbilicus or toes. For example, you can shine a flashlight on the toes or umbilicus or tickle the toes to encourage the child to look down. Look to see if the child can bend his or her neck when looking down at his or her umbilicus or toe<br />\n<b><span class=\"caps\">FEEL</span> <span class=\"caps\">FOR</span> <span class=\"caps\">STIFF</span> <span class=\"caps\">NECK</span>:</b> If you still have not seen the child bend his or her neck himself, ask the caregiver to help you lay the child on his or her back. Lean over the child, gently support the child’s back and shoulders with one hand. With the other hand, hold the child’s head. Then carefully bend the head forward towards the child’s chest. If the neck bends easily, the child does not have stiff neck. If the neck feels stiff and there is resistance to bending, the child has a stiff neck. Often a child with a stiff neck will cry when you try to bend the neck.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B12S2.DE05",
    "text" : "Runny nose",
    "type" : "boolean",
    "required" : true,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true and %resource.repeat(item).where(linkId='Eye Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE01",
    "text" : "Red eyes",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE01-help",
      "text" : "The child has “red eyes” if there is redness in the white part of the eye. In a healthy eye, the white part of the eye is clearly white and not discoloured.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Eye Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE02",
    "text" : "Pus Draining from Eye",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE02-help",
      "text" : "Pus draining from the eye is a sign of conjunctivitis. Conjunctivitis is an infection of the conjunctiva, the inside surface of the eyelid and the white part of the eye.<br />\n<b>If you do not see pus draining from the eye, look for pus on the conjunctiva or on the eyelids.</b> Often the pus forms a crust when the child is sleeping and seals the eye shut. You can gently open the eye, making sure that your hands are clean.<br />\nWash your hands after examining the eye of any child with pus draining from the eye.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Eye Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE03",
    "text" : "Clouding of the Cornea",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE03-help",
      "text" : "The cornea is usually clear. When clouding of the cornea is present, the cornea <b>may appear clouded or hazy.</b> The cornea may look the way a glass of water looks when you add a small amount of milk. <b>The clouding may occur in one or both eyes.</b><br />\nA child with corneal clouding may keep his or her eyes tightly shut when exposed to light. The light may cause irritation and pain to the child’s eyes. To check the child’s eye, wait for the child to open his or her eye. Or gently pull down the lower eyelid to look for clouding.<br />\n<b>Corneal clouding is a dangerous condition.</b> It may be the result of vitamin A deficiency that has been made worse by measles. If the corneal clouding is not treated, the cornea can ulcerate and cause blindness. A child with clouding of the cornea needs urgent treatment with vitamin A.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE03').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE04",
    "text" : "Is Clouding of the Cornea a new problem",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE04-help",
      "text" : "If there is clouding of the cornea, ask the caregiver how long the cloudinghas been present. If the caregiver is certain that clouding has been there for some time, ask if the clouding has already been assessed and treated at the hospital. If it has, you do not need to refer this child again for corneal clouding.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE03').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B14S2.DE04').answer.first().value = false"
      }
    }],
    "linkId" : "Ccc.B14S2.DE05",
    "text" : "Has Clouding of the Cornea previously been treated",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/questionnaire-item-control",
          "code" : "check-box",
          "display" : "Check-box"
        }],
        "text" : "Check-box"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Skin Problem').answer.first().value = true or (%resource.repeat(item).where(linkId='Fever').answer.first().value = true and (%resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B12S2.DE05').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B14S2.DE01').answer.first().value = true))"
      }
    }],
    "linkId" : "Ccc.B14S2.DE06",
    "text" : "Generalised or Localised Skin Problem",
    "type" : "choice",
    "required" : true,
    "repeats" : true,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE07",
        "display" : "Generalised Skin Problem"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE08",
        "display" : "Localised Skin Problem"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE09",
        "display" : "No Problem"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true or ( %resource.repeat(item).where(linkId='Cough').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B12S2.DE05').answer.first().value = true or %resource.repeat(item).where(linkId='Ccc.B14S2.DE01').answer.first().value = true ) and %resource.repeat(item).where(linkId='Ccc.B14S2.DE06').answer.where(value.code =  'Ccc.B14S2.DE07').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE10",
    "text" : "Measles Rash",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE10-help",
      "text" : "In measles, <b>a rash begins behind the ears and on the neck. It spreads to the face.</b> During the next day, the rash spreads to the rest of the body, arms and legs. After 4 to 5 days, the rash starts to fade and the skin may peel.</p>\n\n\t<p>Some children with severe infection may have more rash spread over more of the body. The rash becomes more discoloured (dark brown or blackish), and there is more peeling of the skin. A measles rash does not have vesicles (blisters) or pustules. The rash does not itch.</p>\n\n\t<p>Do not confuse measles with other common childhood rashes such as chicken pox, scabies, or heat rash. Chicken pox rash is a generalized rash with vesicles. Scabies occurs on the hands, feet, ankles, elbows, buttocks and axilla (underarm). It also itches. Heat rash can be a generalized rash with small bumps and vesicles, which itch. A child with heat rash is not sick.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true and (iif(%resource.repeat(item).where(linkId='Ccc.B14S2.DE01').answer.first().value = true, false, true) or iif(%resource.repeat(item).where(linkId='Cough').answer.first().value = true, false, true) or iif(%resource.repeat(item).where(linkId='Ccc.B12S2.DE05').answer.first().value = true, false, true)) or %resource.repeat(item).where(linkId='Ccc.B14S2.DE06').answer.where(value.code =  'Ccc.B14S2.DE07').empty() or %resource.repeat(item).where(linkId='Ccc.B14S2.DE10').answer.first().value = false"
      }
    }],
    "linkId" : "Ccc.B14S2.DE11",
    "text" : "Measles within the last 3 months",
    "type" : "boolean",
    "required" : true,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE11-help",
      "text" : "Ask the caregiver or check the child&#8217;s health record to see if they have had measles in the last 3 months. If the caregiver is not sure, explain the symptoms (a generalised rash all over the body, starting from behind the ears and on the neck, spreading to the face, then the body, arms and legs, accompanied by runny nose, red eyes or cough).",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Danger Signs').answer.first().value = false or %resource.repeat(item).where(linkId='Skin Problem').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE12",
    "text" : "Blisters, Sores or Pustules",
    "type" : "boolean",
    "required" : true,
    "repeats" : false
  },
  {
    "extension" : [{
      "extension" : [{
        "url" : "option",
        "valueCoding" : {
          "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
          "code" : "Ccc.B14S2.DE22"
        }
      },
      {
        "url" : "expression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='Danger Signs').answer.first().value = false and %resource.repeat(item).where(linkId='Itchy Skin').answer.first().value=true and %resource.repeat(item).where(linkId='Ccc.B14S2.DE12').answer.first().value = true and  %resource.repeat(item).where(linkId='Ccc.B14S2.DE06').answer.where(value.code = 'Ccc.B14S2.DE07').empty()"
        }
      }],
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-answerOptionsToggleExpression"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Danger Signs').answer.first().value = false and  ( %resource.repeat(item).where(linkId='Ccc.B14S2.DE06').answer.where(value.code =  'Ccc.B14S2.DE07').exists() or %resource.repeat(item).where(linkId='Ccc.B14S2.DE06').answer.where(value.code =  'Ccc.B14S2.DE08').exists() )"
      }
    }],
    "linkId" : "Ccc.B14S2.DE13",
    "text" : "Type of Skin Problem",
    "type" : "choice",
    "required" : false,
    "repeats" : true,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE18",
        "display" : "Papular Urticaria or Papular Pruritic Eruptions"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE19",
        "display" : "Ringworm (Tinea)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE21",
        "display" : "Scabies"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE22",
        "display" : "Chickenpox"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE23",
        "display" : "Herpes Zoster"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE25",
        "display" : "Impetigo"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE31",
        "display" : "Molluscum Contagiosum"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE32",
        "display" : "Warts"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE33",
        "display" : "Seborrhoeic Dermatitis"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE35",
        "display" : "Fixed Drug Reaction"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE36",
        "display" : "Eczema"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE37",
        "display" : "Steven Johnson Syndrome (SJS)"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "none",
        "display" : "None of the above"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE19').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE19a",
    "text" : "Scalp Infection (tinea capitis)",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE19a-help",
      "text" : "Scalp lesions may result in loss of hair",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE22').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE22A",
    "text" : "Severe rash",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE22A-help",
      "text" : "Severe rash indicates that the child needs referral due to risk of complications.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE23').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE23a",
    "text" : "Disseminated Herpes Zoster",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE23a-help",
      "text" : "Disseminated herpes zoster means that the rash is affecting more than one area of the body",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE23').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE24",
    "text" : "Eye Involvement",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE25').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE30",
    "text" : "Skin Infection extends to Muscle",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE25').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE30b",
    "text" : "Extensive impetigo lesions",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE30b-help",
      "text" : "Impetigo can be considered as extensive if it is greater than 4cm in diameter",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE31').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE31a",
    "text" : "Extensive molluscum lesions",
    "type" : "boolean",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE31a-help",
      "text" : "Molluscum Contagiosum &#8211; Skin coloured pearly white papules with central umbilication. Most commonly seen on face and trunk in children.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE31').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE31b",
    "text" : "Molluscum lesions close to the eye",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE32').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE32a",
    "text" : "Extensive warts",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE33').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE34",
    "text" : "Severe Seborrhoeic Dermatitis",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE36').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE36a",
    "text" : "Secondary bacterial infection of eczema",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE36').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE36b",
    "text" : "Severe acute moist or weeping eczema",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Ccc.B14S2.DE13').answer.where(value.code='Ccc.B14S2.DE36').exists()"
      }
    }],
    "linkId" : "Ccc.B14S2.DE36c",
    "text" : "Secondary herpes infection of eczema (eczema herpeticum)",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/questionnaire-item-control",
          "code" : "radio-button",
          "display" : "Radio Button"
        }],
        "text" : "Radio Button"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Fever').answer.first().value = true"
      }
    }],
    "linkId" : "Ccc.B14S2.DE38",
    "text" : "Oral sores or Mouth Ulcers",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE41",
        "display" : "Mouth Sores or Mouth Ulcers - Deep and Extensive"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE42",
        "display" : "Mouth Sores or Mouth Ulcers - Not Deep and Extensive"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE40",
        "display" : "Oral Thrush"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE39",
        "display" : "No Oral Sores or Mouth Ulcers"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B14S2.DE38-help",
      "text" : "Ulcers are painful open sores on the inside of the mouth and lips or the tongue. They may be red or have white coating.",
      "type" : "display"
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/questionnaire-item-control",
          "code" : "check-box",
          "display" : "Check-box"
        }],
        "text" : "Check-box"
      }
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='Danger Signs').answer.first().value = false"
      }
    }],
    "linkId" : "Ccc.B14S2.DE43",
    "text" : "Add a Skin or Mouth or Eye Problem",
    "type" : "choice",
    "required" : false,
    "repeats" : true,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE44",
        "display" : "Skin Problem"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE45",
        "display" : "Oral Sores or Mouth Ulcers"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE46",
        "display" : "Eye Problem"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B14S2.DE47",
        "display" : "No - Do not add a Skin or Mouth or Eye Problem"
      }
    }]
  },
  {
    "linkId" : "Ccc.B15S2.DE01",
    "text" : "Palmar Pallor",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE02",
        "display" : "Severe Palmar Pallor"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE03",
        "display" : "Some Palmar Pallor"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE04",
        "display" : "No Palmar Pallor"
      }
    }],
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-itemControl",
        "valueCodeableConcept" : {
          "coding" : [{
            "system" : "http://hl7.org/fhir/questionnaire-item-control",
            "code" : "help"
          }]
        }
      }],
      "linkId" : "Ccc.B15S2.DE01-help",
      "text" : "<span class=\"caps\">LOOK</span> at the skin of the child’s palm. Hold the child’s palm open by grasping it gently from the side. Do not stretch the fingers backwards. This may cause pallor by blocking the blood supply. Compare the colour of the child’s palm with your own palm and with the palms of other children. The child has some palmar pallor if the skin of the child’s palm is pale. The child has severe palmar pallor if the skin of the palm is very pale or so pale that it looks white.",
      "type" : "display"
    }]
  },
  {
    "linkId" : "Ccc.B15S2.DE09",
    "text" : "Mucous membrane pallor",
    "type" : "choice",
    "required" : true,
    "repeats" : false,
    "answerOption" : [{
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE10",
        "display" : "Severe mucous membrane pallor"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE11",
        "display" : "Some mucous membrane pallor"
      }
    },
    {
      "valueCoding" : {
        "system" : "https://smart.who.int/ccc/CodeSystem/Ccc-custom-codes",
        "code" : "Ccc.B15S2.DE12",
        "display" : "No mucous membrane pallor"
      }
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate profile"
      }
    }],
    "linkId" : "Respiratory Rate profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "force-collection"
      }
    }],
    "linkId" : "force-collection",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "respiratory rate second count profile"
      }
    }],
    "linkId" : "Respiratory Rate Second Count Profile",
    "type" : "quantity",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "fast breathing profile"
      }
    }],
    "linkId" : "Fast Breathing profile",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "now()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    }],
    "linkId" : "timestamp",
    "type" : "dateTime",
    "required" : false
  }]
}

```
