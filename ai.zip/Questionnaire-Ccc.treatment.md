# Ccc.Treatment - WHO FHIR Implementation Guide (IG): Integrated Management of Childhood Illness (IMCI) in emergencies v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Ccc.Treatment**

## Questionnaire: Ccc.Treatment
Branch:



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "Ccc.treatment",
  "meta" : {
    "profile" : ["http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire"]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "shareable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "computable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeCapability",
    "valueCode" : "publishable"
  },
  {
    "url" : "http://hl7.org/fhir/uv/cpg/StructureDefinition/cpg-knowledgeRepresentationLevel",
    "valueCode" : "structured"
  },
  {
    "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-targetStructureMap",
    "valueCanonical" : "https://smart.who.int/ccc/StructureMap/Ccc.treatment"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/cqf-library",
    "valueCanonical" : "https://smart.who.int/ccc/Library/Ccctreatment"
  }],
  "url" : "https://smart.who.int/ccc/Questionnaire/Ccc.treatment",
  "version" : "0.1.0",
  "name" : "Ccc.Treatment",
  "title" : "Ccc.Treatment",
  "status" : "active",
  "experimental" : false,
  "subjectType" : ["Patient"],
  "date" : "2026-04-07T13:45:53+00:00",
  "publisher" : "World Health Organization (WHO)",
  "contact" : [{
    "name" : "World Health Organization (WHO)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  },
  {
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.who.int"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "ageinmonths"
      }
    }],
    "linkId" : "AgeInMonths",
    "type" : "integer",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value>=2"
      }
    }],
    "linkId" : "child",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE01').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE01",
      "text" : "<h1>Very Severe Disease</h1>\n\n\t<p>➢ <b>Give one dose of rectal diazepam if convulsing now, repeat after 10 minutes if convulsion has not stopped</b></p>\n\n\t<p>➢ <b>Give any pre-referral treatment immediately</b></p>\n\n\t<p>➢ <b>Treat to prevent low blood sugar</b></p>\n\n\t<p>➢ <b>Keep the child warm</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital*.</b></p>\n\n\t<p>*Exception: If lethargy is the only sign and child is dehydrated, rehydrated and assess.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE02').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE02",
      "text" : "<h1>Severe Pneumonia or Very Severe Disease</h1>\n\n\t<p>➢ <b>Give first dose of intramuscular Cefotaxime</b></p>\n\n\t<p>➢If wheezing present, give one dose of rapid acting bronchodilator* pre-referral</p>\n\n\t<p>➢Treat the child to prevent low blood sugar</p>\n\n\t<p>➢Refer <span class=\"caps\">URGENTLY</span> to hospital</p>\n\n\t<p>*Nebulized salbutamol, salbutamol inhaler with spacer, or subcutaneous epinephrine (adrenaline)</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE03').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE03",
      "text" : "<h1>Pneumonia</h1>\n\n\t<p>➢**Give oral Amoxicillin twice daily for 5 days**</p>\n\n\t<p>➢If wheezing (or disappeared after inhaled salbutamol) give inhaled or oral salbutamol three times a day for 5 days*</p>\n\n\t<p>➢Soothe the throat and relieve the cough with a safe remedy.</p>\n\n\t<p>➢If coughing for ≥14 days or recurrent wheeze, refer for possible TB or asthma assessment</p>\n\n\t<p>➢Advise mother when to return immediately</p>\n\n\t<p>➢Follow-up in 3 days</p>\n\n\t<p>➢Give oral Zinc once daily for 10-14 days.</p>\n\n\t<p>*If inhaled bronchodilator is not available, oral salbutamol may be tried but not recommended for treatment of severe acute wheeze.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE04').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE04",
      "text" : "<h1>Cough or Cold</h1>\n\n\t<p>➢If wheezing (or disappeared after inhaled salbutamol) give inhaled or oral salbutamol three times a day for 5 days**</p>\n\n\t<p>➢Soothe the throat and relieve the cough with a safe remedy.</p>\n\n\t<p>➢If coughing for ≥14 days or recurrent wheeze, refer for possible TB or asthma assessment</p>\n\n\t<p>➢Advise mother when to return immediately</p>\n\n\t<p>➢Follow-up in 5 days if not improving</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE05').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE05",
      "text" : "<h1>Severe Dehydration</h1>\n\n\t<p>➢ If child has no other severe classification:* Give fluid for severe dehydration (plan C) OR</p>\n\n\t<p>➢ <b>If child also has another severe classification:</b></p>\n\n    * <b>Refer <span class=\"caps\">URGENTLY</span> to hospital with mother giving frequent sips of <span class=\"caps\">ORS</span> on the way.</b>\n    * <b>Advise the mother to continue breastfeeding.</b>\n\n\t<p>➢If child is 2 years or older and there is cholera in your area, give oral co-trimoxazole twice daily for 3 days or oral erythromycin 4 times a day for 3 days for cholera.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE06').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE06",
      "text" : "<h1>Some Dehydration</h1>\n\n\t<p>➢Give Plan B for some dehydration:</p>\n\n\t<ul>\n\t\t<li>Give <span class=\"caps\">ORS</span> over 4 hrs in clinic, reassess for dehydration and select appropriate plan to continue treatment</li>\n\t</ul>\n\n\t<ul>\n\t\t<li>If mother must leave before completing treatment, give <span class=\"caps\">ORS</span> for 4 hr Plan B treatment plus 2 packets as recommended in Plan A</li>\n\t\t<li>At home, give extra fluid (as much as the child will take)</li>\n\t\t<li>Give oral Zinc once daily for 10 &#8211; 14 days</li>\n\t\t<li>Continue feeding (exclusive breastfeeding if under 6 months)</li>\n\t</ul>\n\n\t<p>➢ <b>If child also has another severe classification:</b></p>\n\n\t<ul>\n\t\t<li><b>Refer <span class=\"caps\">URGENTLY</span> to hospital with mother giving frequent sips of <span class=\"caps\">ORS</span> on the way.</b></li>\n\t\t<li><b>Advise the mother to continue breastfeeding.</b></li>\n\t</ul>\n\n\t<p>➢Advise mother when to return immediately.</p>\n\n\t<p>➢Follow-up in 5 days if not improving.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE07').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE07",
      "text" : "<h1>No Dehydration</h1>\n\n\t<p>➢Give Plan A for no dehydration:</p>\n\n\t<ul>\n\t\t<li>Give extra fluid (as much as the child will take)</li>\n\t\t<li>Teach mother how to give <span class=\"caps\">ORS</span> and give 2 packets to use at home</li>\n\t\t<li>Give oral Zinc once daily for 14 days</li>\n\t\t<li>Continue feeding (exclusive breastfeeding if under 6 months)</li>\n\t</ul>\n\n\t<p>➢ <b>If child also has another severe classification:</b></p>\n\n\t<ul>\n\t\t<li><b>Refer <span class=\"caps\">URGENTLY</span> to hospital with mother giving frequent sips of <span class=\"caps\">ORS</span> on the way.</b></li>\n\t\t<li><b>Advise the mother to continue breastfeeding.</b></li>\n\t</ul>\n\n\t<p>➢Advise mother when to return immediately.</p>\n\n\t<p>➢Follow-up in 5 days if not improving.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE08').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE08",
      "text" : "<h1>Severe Persistent Diarrhoea</h1>\n\n\t<p>➢Treat dehydration before referral unless the child has another severe classification.</p>\n\n\t<p>➢Refer to hospital.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE09').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE09",
      "text" : "<h1>Persistent Diarrhoea</h1>\n\n\t<p>➢Advise the mother on feeding a child who has persistent diarrhoea.</p>\n\n\t<p>➢Give multivitamins and minerals (including zinc once daily) for 14 days.</p>\n\n\t<p>➢Follow-up in 5 days.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE10').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE10",
      "text" : "<h1>Possible Shigella</h1>\n\n\t<p>➢Treat dehydration before referral unless the child has another severe classification.</p>\n\n\t<p>➢Refer to hospital.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE11').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE11",
      "text" : "<h1>Dysentery</h1>\n\n\t<p>➢Give Oral Metronidazole three times daily for 10 days.</p>\n\n\t<p>➢Treat dehydration if present.</p>\n\n\t<p>➢Follow-up in 3 days.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE12').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE12",
      "text" : "<h1>Throat Abscess or Possible Diptheria</h1>\n\n\t<p>➢ <b>Give first dose of intramuscular Procaine Penicillin pre-referral; if unavailable or allergic to penicillin give first dose of oral Erythromycin pre-referral.</b></p>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol for pain or high fever (38.5°C or above).</b></p>\n\n\t<p>➢ <b><span class=\"caps\">REFER</span> <span class=\"caps\">URGENTLY</span> to hospital.</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE13').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE13",
      "text" : "<h1>Streptococcal Sore Throat</h1>\n\n\t<p>➢ <b>Give single dose of intramuscular benzathine penicillin, or if unavailable give oral amoxicillin twice daily for 10 days; if allergic to penicillin give oral erythromycin 4 times daily for 10 days</b></p>\n\n\t<p>➢ **Give oral paracetamol for pain or high fever (38.5°C or above), continue to give every 6 hours (4 times / day) until pain and/or high fever gone. **</p>\n\n\t<p>➢ Soothe the throat with a safe remedy.</p>\n\n\t<p>➢ Follow-up in 5 days if not improving.</p>\n\n\t<p>➢ Advise the mother when to return immediately</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE14').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE14",
      "text" : "h1.Non-Streptococcal Sore Throat</p>\n\n\t<p>➢ <b>Give oral paracetamol for pain or high fever (38.5°C or above), continue to give every 6 hours (4 times / day) until pain/high fever gone.</b></p>\n\n\t<p>➢ Soothe the throat with a safe remedy.</p>\n\n\t<p>➢ Follow-up in 5 days if not improving.</p>\n\n\t<p>➢ Advise the mother when to return immediately",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE15').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE15",
      "text" : "<h1>No Throat Problem</h1>\n\n\t<p>➢ <b>Give oral paracetamol for pain or high fever (38.5°C or above), continue to give every 6 hours (4 times / day) until pain /high fever gone.</b></p>\n\n\t<p>➢ Advise the mother when to return immediately</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE16').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE16",
      "text" : "<h1>Mastoiditis</h1>\n\n\t<p>➢ <b>Give first dose of intramuscular Cefotaxime</b></p>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol for pain or high fever (38.5°C or above).</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE17').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE17",
      "text" : "<h1>Acute Ear Infection</h1>\n\n\t<p>➢ <b>Give an appropriate oral antibiotic:</b></p>\n\n\t<p>     * <b>First-line: Oral Amoxicillin twice daily for 10 days</b>\n     * <b>Second-line: Oral Co-trimoxazole twice daily for 10 days</b>\n     * <b>If allergic to amoxicillin and co-trimoxazole, give Oral Erythromycin 4 times daily for 10 days</b></p>\n\n\t<p>➢ <b>Give oral paracetamol for pain or high fever (38.5°C or above), continue to give every 6 hours (4 times / day) until pain/high fever gone.</b></p>\n\n\t<p>➢ If ear discharge: Dry the ear by wicking at least 3 times daily</p>\n\n\t<p>➢ Advise the mother when to return immediately.</p>\n\n\t<p>➢ Follow-up in 5 days</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE18').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE18",
      "text" : "<h1>Chronic Ear Infection</h1>\n\n\t<p>➢ Dry the ear by wicking</p>\n\n\t<p>➢ Refer to <span class=\"caps\">ENT</span> specialist.</p>\n\n\t<p>➢ <b>If ear pain or fever, give an appropriate oral antibiotic:</b></p>\n\n\t<ul>\n\t\t<li><b>First-line: Oral Amoxicillin twice daily for 10 days</b></li>\n\t\t<li><b>Second-line: Oral Co-trimoxazole twice daily for 10 days</b></li>\n\t\t<li><b>If allergic to amoxicillin and co-trimoxazole, give Oral Erythromycin 4 times daily for 10 days</b></li>\n\t</ul>\n\n\t<p>➢**Give one dose of oral Paracetamol in clinic for pain or high fever (38.5°C or above),** continue to give every 6 hours (4 times / day) until pain/high fever gone.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE19').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE19",
      "text" : "<h1>No Ear Infection</h1>\n\n\t<p>➢No treatment</p>\n\n\t<p>➢Refer to <span class=\"caps\">ENT</span> specialist.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE20').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE20",
      "text" : "<h1>Very Severe Febrile Disease</h1>\n\n\t<p>➢ <b>Give first dose of intramuscular Cefotaxime</b></p>\n\n\t<p>➢ <b>Treat the child to prevent low blood sugar</b></p>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol for high fever (38.5°C or above).</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE21').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE21",
      "text" : "<h1>Fever: Possible Bacterial Infection</h1>\n\n\t<p>➢ Treat apparent cause of fever.</p>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol in clinic for high fever (38.5°C or above).</b> continue to give every 6 hours (4 times / day) until high fever gone. </p>\n\n\t<p>➢ Follow up in 3 days if fever persists</p>\n\n\t<p>➢ Advise the mother when to return immediately</p>\n\n\t<p>➢ If fever present every day for more than 7 days, refer for assessment</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE22').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE22",
      "text" : "<h1>Fever: Bacterial Infection Unlikely</h1>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol in clinic for high fever (38.5°C or above).</b> continue to give every 6 hours (4 times / day) until high fever gone. </p>\n\n\t<p>➢ Follow up in 3 days if fever persists</p>\n\n\t<p>➢ Advise the mother when to return immediately</p>\n\n\t<p>➢ If fever present every day for more than 7 days, refer for assessment</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE23').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE23",
      "text" : "<h1>Severe Complicated Measles</h1>\n\n\t<p>➢ <b>Give first dose of oral Vitamin A if the child has not had a dose within the past month and is not on <span class=\"caps\">RUTF</span></b></p>\n\n\t<p>➢ <b>Give first dose of Intramuscular Cefotaxime</b></p>\n\n\t<p>➢ <b>Give one dose of oral Paracetamol for high fever (38.5°C or above).</b></p>\n\n\t<p>➢ <b>If clouding of the of cornea or pus draining from the eye, apply Tetracycline eye ointment 4 times daily until there is no pus discharge</b></p>\n\n\t<p>➢ <b>Treat to prevent low blood sugar.</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital.</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE24').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE24",
      "text" : "<h1>Measles with eye or mouth complication</h1>\n\n\t<p>➢ <b>Give oral Vitamin A if the child has not had a dose within the past month and is not on <span class=\"caps\">RUTF</span> &#8211; first dose in clinic</b> and one dose to give at home the next day</p>\n\n\t<p>➢ <b>If pus draining from the eye, apply Tetracycline eye ointment 4 times daily until there is no pus discharge</b></p>\n\n\t<p>➢ If mouth ulcers, treat twice daily with gentian violet until 48 hrs after the ulcers have been cured</p>\n\n\t<p>➢ **Give one dose of oral Paracetamol in clinic for pain or high fever (38.5°C or above), continue to give every 6 hours (4 times / day) until pain/high fever gone. </p>\n\n\t<p>➢ Follow up in 3 days</p>\n\n\t<p>➢ Advise mother when to return immediately</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE25').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE25",
      "text" : "<h1>Possible Measles</h1>\n\n\t<p>➢ Send for blood sample</p>\n\n\t<p>➢ <b>Give oral Vitamin A if the child has not had a dose within the past month and is not on <span class=\"caps\">RUTF</span> &#8211; first dose in clinic</b> and one dose to give at home the next day</p>\n\n\t<p>➢ Advise mother when to return immediately.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE42').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE42",
      "text" : "<h1>Severe Anaemia</h1>\n\n\t<p>➢Treat to prevent low blood sugar</p>\n\n\t<p>➢Refer <b><span class=\"caps\">URGENTLY</span></b> to hospital.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE43').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE43",
      "text" : "<h1>Anaemia</h1>\n\n\t<p>➢Give oral Iron* once daily for 14 days</p>\n\n\t<p>➢Assess the child`s feeding and counsel the mother on feeding according to the <span class=\"caps\">FOOD</span> box or the <span class=\"caps\">COUNSEL</span> <span class=\"caps\">THE</span> <span class=\"caps\">MOTHER</span> chart.</p>\n\n\t<p>➢Advise mother when to return immediately</p>\n\n\t<p>➢If feeding problem, follow-up in 5 days.</p>\n\n\t<p>➢Follow -up in 14 days &amp; do Hb;</p>\n\n\t<p>➢If no improvement or rise in Hb refer.</p>\n\n\t<p>*Except if the child has sickle cell aneamia or thalassaemia or family history of any hemolytic disease e.g., G6PD which need urgent treatment.\n\t\t<ul>\n\t\t\t<li>Signs of hemolysis: Jaundice, change color of urine, sudden severe pallor, weakness.</li>\n\t\t</ul></li></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE44').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE44",
      "text" : "<h1>No Anaemia</h1>\n\n\t<p>➢Counsel the mother on feeding.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE26').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE26",
      "text" : "<h1>Eye Infection</h1>\n\n\t<p>➢ <b>If pus draining from the eye, apply Tetracycline eye ointment 4 times daily until there is no pus discharge</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE27').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE27",
      "text" : "<h1>Clouding of the Cornea</h1>\n\n\t<p>➢If clouding of the cornea is new or not previously treated, <span class=\"caps\">REFER</span></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE28').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE28",
      "text" : "<h1>Papular Urticaria or Papular Pruritic Eruptions</h1>\n\n\t<p>➢Trim finger nails and avoid scratching.</p>\n\n\t<ul>\n\t\t<li>Apply 1% hydrocortisone to new, inflamed lesions for five days.</li>\n\t\t<li>Give oral antihistamine to relieve itch:\n\t\t<ul>\n\t\t\t<li>Short term use: Chlorphenamine, oral, 0.1mg/kg/ dose 6-8 hourly</li>\n\t\t\t<li>Long term use for children 2-6 years: Cetirizine,oral, 5mg once daily</li>\n\t\t\t<li>Caution: Do not give antihistamines to children< 2 years of age.</li>\n\t\t</ul></li>\n\t\t</ul>\n\n\t<p>➢Refer if no improvement after 2 weeks or if underlying malignancy or systemic disease is suspected.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE29').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE29",
      "text" : "<h1>Ringworm (tinea)</h1>\n\n\t<p>➢Avoid sharing clothes, towels and toiletries (e.g. brushes and combs) to prevent spreading the infection to others.</p>\n\n\t<ul>\n\t\t<li>Wash and dry skin well before applying treatment.</li>\n\t\t<li>Apply an imidazole (e.g. clotrimazole 1% cream) three times daily until two weeks after lesions have cleared.</li>\n\t\t<li>For scalp infections (tinea capitis) give oral fluconazole 6mg/kg once daily for 28 days</li>\n\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE30').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE30",
      "text" : "<h1>Scabies</h1>\n\n\t<p>➢All close contacts should be treated simultaneously (even if not itchy).</p>\n\n\t<ul>\n\t\t<li>Wash all bed linen and underwear in hot water</li>\n\t\t<li>Expose all bedding to direct sunlight.</li>\n\t\t<li>Put on clean clothes after treatment.\n <br />\n➢Treat the child and contacts under 6 years of age with Permethrin:</li>\n\t</ul>\n\n\t<ul>\n\t\t<li>Apply permethrin 5% lotion. Leave on overnight and washoff in the morning (may be repeated after one week).</li>\n\t\t<li>Treatment may need to be repeated after one week.</li>\n\t\t<li>Treat secondary bacterial infection, if present, with Oral Cephalexin 12-25mg/kg/dose 6 hourly for 5 days</li>\n\t</ul>\n\n\t<p>➢Treat contacts over 6 years of age with Benzyl Benzoate:</p>\n\n\t<ul>\n\t\t<li>Apply benzyl benzoate 25% from the neck to the toes. Allow the lotion to remain on the body for 24 hours, then wash off using soap and water</li>\n\t\t<li>Treatment may need to be repeated after one week.</li>\n\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE31').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE31",
      "text" : "<h1>Chickenpox</h1>\n\n\t<p>➢Limit contact with other children and pregnant women until all lesions have crusted.</p>\n\n\t<ul>\n\t\t<li>Ensure adequate hydration.</li>\n\t\t<li>Cut fingernails short and discourage scratching.</li>\n\t\t<li>Treat itching:\n\t\t<ul>\n\t\t\t<li>Apply calamine lotion</li>\n\t\t\t<li>In severe cases, give an oral antihistamine:Chlorphenamine 0.1 mg/kg/dose 6–8 hourly NB: Only children >2 years.</li>\n\t\t</ul></li>\n\t\t</ul>\n\n\t<p>➢Refer urgently if severe rash or complications (e.g. pneumonia, jaundice, meningitis, myocarditis, hepatitis).</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE32').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE32",
      "text" : "<h1>Herpes Zoster</h1>\n\n\t<p>➢Keep lesions clean and dry.\n\t<ul>\n\t\t<li>Acyclovir 20 mg/kg 4 times daily for 7 days.</li>\n\t\t<li>Give oral Paracetamol for pain relief, continue to give every 6 hours (4 times / day) until pain gone</li>\n\t\t<li>Follow up in 7 days.</li>\n\t\t<li>Refer if disseminated disease, involvement of the eye, pneumonia or features meningitis.</li>\n\t\t<li>Monitor for secondary bacterial infection &#8211; if present, treat with Oral Cephalexin 12-25mg/kg/dose 6 hourly for 5 days</li>\n\t</ul></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE33').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE33",
      "text" : "<h1>Impetigo</h1>\n\n\t<p>➢Good personal and household hygiene to avoid spread of infection.</p>\n\n\t<p>➢Wash and soak sores in soapy water to soften and remove crusts.</p>\n\n\t<p>➢Apply antiseptic 8 hourly: Povidone iodine 5% cream or 10% ointment.</p>\n\n\t<p>➢Drain pus if fluctuant.</p>\n\n\t<p>➢Give antibiotic if extensive lesions: Cephalexin, oral, 12-25mg/kg/dose 6 hourly for 5 days</p>\n\n\t<p>➢Refer urgently if child has fever and or if infection extends to the muscles.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE34').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE34",
      "text" : "<h1>Molluscum Contagiosum</h1>\n\n\t<p>➢Allow to heal spontaneously if few in number.\n\t<ul>\n\t\t<li>Apply a tincture of iodine BP to the core of individual lesions using an applicator.</li>\n\t\t<li>Refer children with:\n\t\t<ul>\n\t\t\t<li>Extensive lesions</li>\n\t\t</ul></li>\n\t\t</ul></p>\n\n\t<p>        &#8211; No response to treatment</p>\n\n\t<p>        &#8211; Lesions close to the eye (to an ophthalmologist).</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE35').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE35",
      "text" : "<h1>Warts</h1>\n\n\t<p>➢May be left alone to wait for improvement</p>\n\n\t<p>➢Apply salicylic acid 15-20% to the warts\n\t\t<ul>\n\t\t\t<li>Protect surrounding skin with petroleum jelly</li>\n\t\t\t<li>Apply daily to the wart and allow to dry</li>\n\t\t\t<li>Occlude for 24 hours-Soften lesions by soaking in warm water, and remove loosened keratin.</li>\n\t\t\t<li>Repeat process daily until the warts disappear.</li>\n\t\t</ul></li></p>\n\n\t<p>➢Refer if extensive</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE36').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE36",
      "text" : "<h1>Seborrhoeic Dermatitis</h1>\n\n\n\t<p>➢Apply hydrocortisone 1% cream to the face and flexures.</p>\n\n\t<ul>\n\t\t<li>For scalp itching, scaling and dandruff: wash hair and scalp 2-3 times a week with selenium suphide 2.5% suspension.</li>\n\t\t<li>If severe, <span class=\"caps\">REFER</span>.</li>\n\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE37').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE37",
      "text" : "<h1>Fixed Drug Reaction</h1>\n\n\t<p>➢ Stop the offending medication.</p>\n\n\t<ul>\n\t\t<li>In mild cases, apply 1% hydrocortisone for five days.</li>\n\t\t<li>Discuss all cases with a doctor.</li>\n\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE38').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE38",
      "text" : "<h1>Eczema</h1>\n\n\t<p>➢ Bath in warm water using soap substitutes only once daily.</p>\n\n\t<ul>\n\t\t<li>Dry skin gently.</li>\n\t\t<li>Apply Hydrocortisone 1% cream followed by application of moisturizer (emulsifying ointment).</li>\n\t\t<li>If over 2 years of age treat itching oral chlorphenamine 0.1 mg/kg/dose 6–8hourly</li>\n\t\t<li>Treat secondary infection: Oral Cephalexin, 12–25 mg/kg/dose 6 hourly for 5 days OR: Oral Flucloxacillin, 12–25mg/kg/dose 6 hourly for 5 days.</li>\n\t\t<li>Refer if:\n\t\t<ul>\n\t\t\t<li>severe acute moist or weeping eczema is present</li>\n\t\t\t<li>no improvement after two weeks</li>\n\t\t\t<li>Secondary herpes infection (eczema herpeticum) is suspected</li>\n\t\t</ul></li>\n\t\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE39').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE39",
      "text" : "<h1>Steven Johnson Syndrome (<span class=\"caps\">SJS</span>)</h1>\n\n\t<p>➢ Stop medication</p>\n\n\t<ul>\n\t\t<li><span class=\"caps\">REFER</span> <span class=\"caps\">URGENTLY</span></li>\n\t\t<li>Give frequent sips of <span class=\"caps\">ORS</span> on way to hospital</li>\n\t\t<li>Give one dose of oral Paracetamol for pain pre-referral</li>\n\t</ul>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE40').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE40",
      "text" : "h1.Mouth Sores or Ulcer</p>\n\n\t<p>➢ Treat mouth ulcers twice daily with gentian violet until 48 hrs after the ulcers have been cured</p>\n\n\t<p>➢ Give oral Paracetamol every 6 hours (4 times / day) for pain until pain is gone</p>\n\n\t<p>➢ Refer if mouth ulcers deep or extensive",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE41').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE41",
      "text" : "<h1>Oral Thrush</h1>\n\n\t<p>➢ Give half-strength gentian violet (0.25%) 4 times daily for 7 days.</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE45').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE45",
      "text" : "<h1>Very Low Weight for Age</h1>\n\n\t<p>➢ Refer to nutrition clinic for further assessment</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE46').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE46",
      "text" : "<h1>Low Weight for Age</h1>\n\n\t<p>➢ Refer to nutrition clinic for further assessment</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE47').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE47",
      "text" : "<h1>How Muac or Visual Report of Wasting</h1>\n\n\t<p>➢ Refer to nutrition clinic for further assessment</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "%resource.repeat(item).where(linkId='AgeInMonths').answer.first().value<2"
      }
    }],
    "linkId" : "yi",
    "type" : "group",
    "required" : false,
    "repeats" : false,
    "item" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE48').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE48",
      "text" : "<h1>Possible Serious Bacterial Infection or Very Severe Disease</h1>\n\n\t<p>➢ <b>Give first dose of intramuscuar (IM) antibiotics</b></p>\n\n\t<ul>\n\t\t<li><b>Give a first dose of intramuscular gentamicin</b></li>\n\t</ul>\n\n    <span class=\"caps\">AND</span> \n\n\t<ul>\n\t\t<li><b>Give a first dose of intramuscular ampicillin. OR, if IM ampicillin is not avaialble, give a first dose of oral amoxicillin, at the dose indicated for Pneumonia</b></li>\n\t</ul>\n\n\t<p>➢ <b>Treat to prevent low blood sugar</b></p>\n\n\t<p>➢ <b>Advise the mother on how to keep infant warm on the way to hospital</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital</b> </p>\n\n\t<p>OR</p>\n\n\t<p>➢ <b>If referral <span class=\"caps\">REFUSED</span> or <span class=\"caps\">NOT</span> <span class=\"caps\">FEASIBLE</span> treat in the clinic untill referral is feasible  (see charts on pages 12-13, and 19-20 and Treat Possible Serious Bacterial Infection or Very Severe Disease if referral is refused or is not feasible)</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE49').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE49",
      "text" : "<h1>Pneumonia</h1>\n\n\t<p>➢ <b>Give oral amoxicillin 2 times per day, for 7 days</b></p>\n\n\t<p>➢ Advise the mother to give home care</p>\n\n\t<p>➢ Follow up in 3 days</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE50').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE50",
      "text" : "<h1>Local Infection</h1>\n\n\t<p>➢ <b>Give oral amoxicillin 2 times per day, for 5 days</b></p>\n\n\t<p>➢ Teach the mother how to treat local infections at home</p>\n\n\t<p>➢ Advise the mother to give home care</p>\n\n\t<p>➢ Follow up in 2 days</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE51').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE51",
      "text" : "<h1>Infection Unlikely</h1>\n\n\t<p>➢Advise the mother on giving home care to the young infant</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE52').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE52",
      "text" : "Severe Jaundice</p>\n\n\t<p>➢ <b>Treat to prevent low blood sugar</b></p>\n\n\t<p>➢ <b>Advise the mother how to keep the infant warm on the way to the hospital</b></p>\n\n\t<p>➢ <b>Refer <span class=\"caps\">URGENTLY</span> to hospital</b>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE53').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE53",
      "text" : "<h1>Jaundice</h1>\n\n\t<p>➢Advise the mother to give home care</p>\n\n\t<p>➢Advise the mother to return immediately if the infant&#8217;s palms or soles appear yellow</p>\n\n\t<p>➢If young infant is older than 3 weeks, refer to hospital for assessment</p>\n\n\t<p>➢Follow-up in 1 day</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE54').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE54",
      "text" : "<h1>No Jaundice</h1>\n\n\t<p>➢Advise the mother on giving home care to the young infant</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE55').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE55",
      "text" : "<h1>Severe Dehydration</h1>\n\n\t<p>➢ <b>If infant has no other severe classification:</b></p>\n\n\t<ul>\n\t\t<li><b>Give fluid for Severe Dehydration (Plan A ) OR</b></li>\n\t</ul>\n\n\t<p>➢ <b>If infant has another severe classification:</b></p>\n\n\t<ul>\n\t\t<li><b>Refer <span class=\"caps\">URGENTLY</span> to hospital with the mother giving frequent sips of oral rehydration salts (<span class=\"caps\">ORS</span>) on the way.</b></li>\n\t\t<li><b>Advise the mother to continue  breastfeeding.</b></li>\n\t</ul>\n\n\t<p>➢ <b>Advise the mother how to keep the infant warm on the way to the hospital.</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE56').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE56",
      "text" : "<h1>Some Dehydration</h1>\n\n\t<p>➢Give fluid and breastmilk for Some Dehydration (Plan B)</p>\n\n\t<p>OR</p>\n\n\t<p>➢ <b>If the infant has another severe classification:</b></p>\n\n\t<ul>\n\t\t<li><b>Refer <span class=\"caps\">URGENTLY</span> to hospital with the   mother giving frequent sips of <span class=\"caps\">ORS</span> on the   way</b></li>\n\t\t<li><b>Advise the mother to continue breast feeding</b></li>\n\t</ul>\n\n\t<p>➢Advise the mother when to return immediately</p>\n\n\t<p>➢Follow-up in 2 days if no improvement</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE57').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE57",
      "text" : "<h1>No Dehydration</h1>\n\n\t<p>➢Give fluids and breastmilk to treat diarrhoea at home (Plan A)</p>\n\n\t<p>➢Advise the mother when to return immediately</p>\n\n\t<p>➢Follow-up in 2 days if no improvement</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE58').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE58",
      "text" : "<h1>Very Low Weight for Age</h1>\n\n\t<p>➢ <b><span class=\"caps\">REFER</span> to hospital for Kangaroo Mother Care</b></p>\n\n\t<p>➢ <b>Treat to prevent low blood sugar</b></p>\n\n\t<p>➢ <b>Advise the mother to keep the young infant warm on the way to hospital</b></p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE59').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE59",
      "text" : "<h1>No Feeding Problem</h1>\n\n\t<p>➢Advise mother on giving home care to the young infant</p>\n\n\t<p>➢Praise the mother for feeding the infant well</p>\n\n\t<p>➢If not breastfed, advise mother to continue feeding, and ensure good hygiene</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-enableWhenExpression",
        "valueExpression" : {
          "language" : "text/fhirpath",
          "expression" : "%resource.repeat(item).where(linkId='load-Ccc.C10.IT.DE60').answer.first().value=true"
        }
      }],
      "linkId" : "Ccc.C10.IT.DE60",
      "text" : "<h1>Feeding Problem and / or Low Weight for Age</h1>\n\n\t<p>➢Among infants who are breastfed:</p>\n\n\t<ul>\n\t\t<li>If not well attached or not sucking effectively, teach correct positioning and attachment</li>\n\t\t<li>If not able to attach well immediately, teach the mother to express breastmilk and feed from a cup</li>\n\t\t<li>If breastfeeding less than 8 times in 24 hours, advise the mother to increase the frequency and to breastfeed as often and for as long as the infant wants, day and night</li>\n\t\t<li>If the infant is receiving other foods or drinks, counsel the mother to increase breastfeeding, reduce other foods and drink and use a cup</li>\n\t</ul>\n\n\t<p>➢Among infants who are not breastfed: </p>\n\n\t<ul>\n\t\t<li>Counsel about feeding</li>\n\t\t<li>Explain the guidelines for safe replacement feeding and correct preparation of breastmilk substitutes</li>\n\t\t<li>Identify concerns of mother and family about feeding</li>\n\t\t<li>If mother is using a bottle, teach cup feeding</li>\n\t\t<li>Refer for breastfeeding counselling and possible relactation if the mother is alive and caring for the infant</li>\n\t</ul>\n\n\t<p>➢If Low Weight for Age, advise the mother on how to feed and keep the low-weight infant warm at home</p>\n\n\t<p>➢If the infant has thrush, teach the mother to treat thrush at home</p>\n\n\t<ul>\n\t\t<li>Give half-strength gentian violet (0.25%) 4 times daily for 7 days. Paint the mouth with gentian violet using a clean soft cloth wrapped around the finger. If gentian violet is not  avaialble, write a prescription for the medication for the mother and urge her to visit a pharmacy to purchase the medication.\n <br />\n➢Advise the mother on giving home care to the young infant</li>\n\t</ul>\n\n\t<p>➢Follow up Feeding Problem or Thrush in 2 days</p>\n\n\t<p>➢Among infants who are breastfed, follow up infants who have Low Weight for Age within 14 days</p>\n\n\t<p>➢Among infants who are not breastfed, follow up infants who have Low Weight for Age within 7 days</p>",
      "type" : "display",
      "required" : false,
      "repeats" : false
    }]
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de01"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE01",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de02"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE02",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de03"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE03",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de04"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE04",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de05"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE05",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de06"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE06",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de07"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE07",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de08"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE08",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de09"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE09",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de10"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE10",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de11"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE11",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de12"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE12",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de13"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE13",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de14"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE14",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de15"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE15",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de16"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE16",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de17"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE17",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de18"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE18",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de19"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE19",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de20"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE20",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de21"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE21",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de22"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE22",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de23"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE23",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de24"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE24",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de25"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE25",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de42"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE42",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de43"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE43",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de44"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE44",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de26"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE26",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de27"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE27",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de28"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE28",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de29"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE29",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de30"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE30",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de31"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE31",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de32"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE32",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de33"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE33",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de34"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE34",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de35"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE35",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de36"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE36",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de37"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE37",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de38"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE38",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de39"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE39",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de40"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE40",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de41"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE41",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de45"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE45",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de46"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE46",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de47"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE47",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de48"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE48",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de49"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE49",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de50"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE50",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de51"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE51",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de52"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE52",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de53"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE53",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de54"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE54",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de55"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE55",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de56"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE56",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de57"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE57",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de58"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE58",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de59"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE59",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-choiceOrientation",
      "valueCode" : "horizontal"
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    },
    {
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-initialExpression",
      "valueExpression" : {
        "language" : "text/cql-identifier",
        "expression" : "load-Ccc.c10.it.de60"
      }
    }],
    "linkId" : "load-Ccc.C10.IT.DE60",
    "type" : "boolean",
    "required" : false,
    "repeats" : false
  },
  {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/sdc/StructureDefinition/sdc-questionnaire-calculatedExpression",
      "valueExpression" : {
        "language" : "text/fhirpath",
        "expression" : "now()"
      }
    },
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/questionnaire-hidden",
      "valueBoolean" : true
    }],
    "linkId" : "timestamp",
    "type" : "dateTime",
    "required" : false
  }]
}

```
